import { useState } from "react";
import { AnimatePresence } from "motion/react";
import { Starfield } from "./components/Starfield";
import { Nav } from "./components/Nav";
import { BootSequence } from "./components/BootSequence";
import { Hero } from "./components/Hero";
import { Gallery } from "./components/Gallery";
import { Orrery } from "./components/Orrery";
import { DeepSky } from "./components/DeepSky";
import { Exoplanets } from "./components/Exoplanets";
import { CompositionLab } from "./components/CompositionLab";
import { Timeline } from "./components/Timeline";
import { AboutJWST } from "./components/AboutJWST";
import { Footer } from "./components/Footer";

export default function App() {
  const [booted, setBooted] = useState(false);

  return (
    <div className="relative min-h-screen w-full overflow-x-hidden" style={{ background: "#05060A" }}>
      <Starfield />
      <AnimatePresence>{!booted && <BootSequence onDone={() => setBooted(true)} />}</AnimatePresence>
      {booted && (
        <>
          <Nav />
          <Hero />
          <Gallery />
          <Orrery />
          <DeepSky />
          <Exoplanets />
          <CompositionLab />
          <Timeline />
          <AboutJWST />
          <Footer />
        </>
      )}
    </div>
  );
}
