import { useState } from "react";
import { AnimatePresence, motion } from "motion/react";
import { SectionHeading } from "./SectionHeading";

const PARTS = [
  {
    id: "mirror",
    name: "Primary Mirror",
    spec: "6.5 m · 18 gold-coated beryllium hexagons · collects 6.25× more light than Hubble.",
  },
  {
    id: "sunshield",
    name: "Sunshield",
    spec: "5 layers · tennis-court sized · drops temperature by ~300 °C.",
  },
  {
    id: "nircam",
    name: "NIRCam",
    spec: "Near-Infrared Camera · 0.6–5 µm · the workhorse of deep-field imaging.",
  },
  {
    id: "miri",
    name: "MIRI",
    spec: "Mid-Infrared Instrument · 5–28 µm · operates at −266 °C, near absolute zero.",
  },
  {
    id: "nirspec",
    name: "NIRSpec",
    spec: "Near-IR spectrograph · simultaneously studies 100+ objects with micro-shutters.",
  },
  {
    id: "fgs",
    name: "FGS/NIRISS",
    spec: "Fine guidance + tunable filter · stabilizes Webb to within 7 milliarcseconds.",
  },
];

const HEX = Array.from({ length: 18 }).map((_, i) => i);
function hexPos(i: number) {
  if (i === 0) return { x: 0, y: 0 };
  if (i <= 6) {
    const a = ((i - 1) * 60 - 30) * (Math.PI / 180);
    return { x: Math.cos(a) * 36, y: Math.sin(a) * 36 };
  }
  const a = ((i - 7) * (360 / 11)) * (Math.PI / 180);
  return { x: Math.cos(a) * 72, y: Math.sin(a) * 72 };
}

export function AboutJWST() {
  const [part, setPart] = useState(PARTS[0]);

  return (
    <section id="telescope" className="relative px-6 py-32 lg:px-12">
      <div className="mx-auto max-w-[1400px]">
        <SectionHeading
          eyebrow="07 · ABOUT JWST"
          title="The machine that"
          emphasis="changed seeing."
          body="A folded origami of mirrors, kapton, and beryllium — engineered to detect heat 13.6 billion years old."
        />

        <div className="grid gap-8 lg:grid-cols-[1.3fr_1fr]">
          <div
            className="glass glass-panel relative overflow-hidden"
            style={{
              aspectRatio: "16/11",
              background:
                "radial-gradient(ellipse at center, rgba(255,181,71,0.1), transparent 60%), #060812",
            }}
          >
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <div className="relative">
                <div
                  className="absolute left-1/2 top-full mt-3 -translate-x-1/2"
                  style={{
                    width: 280,
                    height: 8,
                    background:
                      "linear-gradient(180deg, rgba(255,255,255,0.4), rgba(255,255,255,0.1))",
                    borderRadius: 4,
                    transform: "perspective(400px) rotateX(60deg)",
                    opacity: 0.4,
                    boxShadow: "0 0 24px rgba(124,92,255,0.4)",
                  }}
                />
                {[0, 1, 2].map((i) => (
                  <button
                    key={`shield-${i}`}
                    onClick={() => setPart(PARTS[1])}
                    className="absolute -translate-x-1/2 cursor-pointer"
                    style={{
                      left: "50%",
                      top: 80 + i * 12,
                      width: 340 - i * 10,
                      height: 18,
                      background: `linear-gradient(180deg, rgba(255,255,255,${0.18 - i * 0.04}), rgba(255,255,255,${0.06 - i * 0.02}))`,
                      transform: `perspective(400px) rotateX(60deg) skewX(-${10 - i * 2}deg)`,
                      borderRadius: 100,
                      border: "1px solid rgba(255,255,255,0.12)",
                    }}
                  />
                ))}
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 100, repeat: Infinity, ease: "linear" }}
                  className="relative"
                  style={{ width: 200, height: 220 }}
                >
                  {HEX.map((i) => {
                    const p = hexPos(i);
                    return (
                      <button
                        key={i}
                        onClick={() => setPart(PARTS[0])}
                        className="absolute left-1/2 top-1/2 cursor-pointer transition-transform hover:scale-110"
                        style={{
                          width: 36,
                          height: 40,
                          marginLeft: -18,
                          marginTop: -20,
                          transform: `translate(${p.x}px, ${p.y}px)`,
                          clipPath:
                            "polygon(25% 5%, 75% 5%, 100% 50%, 75% 95%, 25% 95%, 0% 50%)",
                          background:
                            "linear-gradient(135deg, #FFE6A8 0%, #FFB547 50%, #FF6B9D 100%)",
                          boxShadow:
                            "0 0 16px rgba(255,181,71,0.5), inset 0 1px 0 rgba(255,255,255,0.5)",
                          border: "none",
                        }}
                      />
                    );
                  })}
                </motion.div>
              </div>
              <div
                className="font-mono mt-12"
                style={{ fontSize: 10, letterSpacing: "0.22em", color: "rgba(255,255,255,0.4)" }}
              >
                CLICK ANY COMPONENT TO INSPECT
              </div>
            </div>
          </div>

          <div className="flex flex-col gap-3">
            {PARTS.map((p) => (
              <button
                key={p.id}
                onClick={() => setPart(p)}
                className="glass glass-card flex items-start gap-4 p-5 text-left transition-all"
                style={{
                  border:
                    part.id === p.id
                      ? "1px solid rgba(255,181,71,0.5)"
                      : "1px solid rgba(255,255,255,0.12)",
                  background:
                    part.id === p.id
                      ? "linear-gradient(135deg, rgba(255,181,71,0.14), rgba(124,92,255,0.1))"
                      : "rgba(255,255,255,0.04)",
                }}
              >
                <div
                  className="mt-1 size-2 rounded-full"
                  style={{
                    background:
                      part.id === p.id ? "var(--accent-gold)" : "rgba(255,255,255,0.3)",
                    boxShadow: part.id === p.id ? "0 0 10px var(--accent-gold)" : "none",
                  }}
                />
                <div className="flex-1">
                  <div className="font-heading" style={{ fontSize: 16 }}>
                    {p.name}
                  </div>
                  <AnimatePresence mode="wait">
                    {part.id === p.id && (
                      <motion.div
                        key={p.id}
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: "auto" }}
                        exit={{ opacity: 0, height: 0 }}
                        transition={{ duration: 0.4 }}
                        style={{ overflow: "hidden" }}
                      >
                        <p
                          className="mt-2"
                          style={{ color: "var(--text-secondary)", fontSize: 13, lineHeight: 1.65 }}
                        >
                          {p.spec}
                        </p>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
