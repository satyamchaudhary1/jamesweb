import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "motion/react";

const LINES = [
  "Calibrating primary mirror segments…",
  "Cooling MIRI to −233 °C…",
  "Aligning with L2 halo orbit…",
  "Opening sunshield…",
  "Stellaris online.",
];

const HEX = Array.from({ length: 18 }).map((_, i) => i);

function hexPos(i: number) {
  const ring = i === 0 ? 0 : i <= 6 ? 1 : 2;
  let angle = 0;
  let r = 0;
  if (ring === 0) return { x: 0, y: 0 };
  if (ring === 1) {
    r = 56;
    angle = ((i - 1) * 60 - 30) * (Math.PI / 180);
  } else {
    r = 112;
    angle = ((i - 7) * (360 / 11)) * (Math.PI / 180);
  }
  return { x: Math.cos(angle) * r, y: Math.sin(angle) * r };
}

export function BootSequence({ onDone }: { onDone: () => void }) {
  const [step, setStep] = useState(0);
  const [progress, setProgress] = useState(0);
  const [done, setDone] = useState(false);

  useEffect(() => {
    const stepT = setInterval(() => setStep((s) => Math.min(s + 1, LINES.length - 1)), 700);
    const progT = setInterval(() => {
      setProgress((p) => {
        if (p >= 100) return 100;
        return p + 1.6;
      });
    }, 40);
    return () => {
      clearInterval(stepT);
      clearInterval(progT);
    };
  }, []);

  useEffect(() => {
    if (progress >= 100 && !done) {
      setDone(true);
      setTimeout(onDone, 900);
    }
  }, [progress, done, onDone]);

  return (
    <AnimatePresence>
      <motion.div
        key="boot"
        initial={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.8 }}
        className="fixed inset-0 z-[100] flex flex-col items-center justify-center"
        style={{ background: "#05060A" }}
      >
        <motion.div
          animate={done ? { scale: 1.2, opacity: 0 } : {}}
          transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
          className="relative"
          style={{ width: 320, height: 320 }}
        >
          {HEX.map((i) => {
            const p = hexPos(i);
            return (
              <motion.div
                key={i}
                initial={{ x: 0, y: 0, scale: 0, opacity: 0, rotate: 30 }}
                animate={{ x: p.x, y: p.y, scale: 1, opacity: 1, rotate: 0 }}
                transition={{
                  delay: 0.05 * i,
                  duration: 0.9,
                  ease: [0.22, 1, 0.36, 1],
                }}
                className="absolute left-1/2 top-1/2"
                style={{
                  width: 56,
                  height: 64,
                  marginLeft: -28,
                  marginTop: -32,
                  clipPath:
                    "polygon(25% 5%, 75% 5%, 100% 50%, 75% 95%, 25% 95%, 0% 50%)",
                  background:
                    "linear-gradient(135deg, #FFB547 0%, #FF6B9D 60%, #7C5CFF 100%)",
                  boxShadow: "0 0 24px rgba(255,181,71,0.4), inset 0 0 12px rgba(255,255,255,0.4)",
                }}
              />
            );
          })}
          {done && (
            <motion.div
              initial={{ scale: 0, opacity: 1 }}
              animate={{ scale: 30, opacity: 0 }}
              transition={{ duration: 0.7 }}
              className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 rounded-full"
              style={{
                width: 40,
                height: 40,
                background: "white",
                boxShadow: "0 0 80px white",
              }}
            />
          )}
        </motion.div>

        <div className="mt-16 flex w-[420px] max-w-[80vw] flex-col items-center gap-4">
          <div className="font-mono h-5 text-center" style={{ fontSize: 12, color: "rgba(255,255,255,0.72)" }}>
            {LINES[step]}
          </div>
          <div
            className="relative h-[2px] w-full overflow-hidden rounded-full"
            style={{ background: "rgba(255,255,255,0.08)" }}
          >
            <motion.div
              className="absolute inset-y-0 left-0"
              animate={{ width: `${progress}%` }}
              transition={{ ease: "linear", duration: 0.04 }}
              style={{
                background: "linear-gradient(90deg, #7C5CFF, #FF6B9D, #FFB547)",
                boxShadow: "0 0 12px #7C5CFF",
              }}
            />
          </div>
          <div className="font-mono flex w-full justify-between" style={{ fontSize: 10, color: "rgba(255,255,255,0.4)" }}>
            <span>JWST · L2 ORBIT</span>
            <span>{Math.round(progress)}%</span>
          </div>
        </div>
      </motion.div>
    </AnimatePresence>
  );
}
