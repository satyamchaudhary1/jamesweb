import { useMemo, useState } from "react";
import { motion } from "motion/react";
import { PLANETS, MOLECULES, ELEMENT_COLORS } from "./data";
import { Planet } from "./Planet";
import { SectionHeading } from "./SectionHeading";

function Molecule3D({ moleculeIdx }: { moleculeIdx: number }) {
  const [rot, setRot] = useState({ x: -15, y: 25 });
  const [dragging, setDragging] = useState(false);
  const m = MOLECULES[moleculeIdx];

  const scale = 60;

  return (
    <div
      className="relative flex items-center justify-center"
      style={{ height: 320, perspective: 1000, cursor: dragging ? "grabbing" : "grab" }}
      onMouseDown={() => setDragging(true)}
      onMouseUp={() => setDragging(false)}
      onMouseLeave={() => setDragging(false)}
      onMouseMove={(e) => {
        if (dragging) {
          setRot((r) => ({ x: r.x - e.movementY * 0.6, y: r.y + e.movementX * 0.6 }));
        }
      }}
    >
      <div
        style={{
          transformStyle: "preserve-3d",
          transform: `rotateX(${rot.x}deg)`,
          position: "relative",
          width: 0,
          height: 0,
        }}
      >
      <motion.div
        animate={dragging ? { rotateY: rot.y } : { rotateY: rot.y + 360 }}
        transition={dragging ? { duration: 0 } : { duration: 24, repeat: Infinity, ease: "linear", repeatType: "loop" }}
        style={{
          transformStyle: "preserve-3d",
          position: "relative",
          width: 0,
          height: 0,
        }}
      >
        {m.bonds.map(([a, b], i) => {
          const A = m.atoms[a];
          const B = m.atoms[b];
          const dx = (B.x - A.x) * scale;
          const dy = (B.y - A.y) * scale;
          const dz = (B.z - A.z) * scale;
          const length = Math.sqrt(dx * dx + dy * dy + dz * dz);
          const yaw = (Math.atan2(dx, dz) * 180) / Math.PI;
          const pitch = (-Math.asin(dy / length) * 180) / Math.PI;
          return (
            <div
              key={i}
              style={{
                position: "absolute",
                width: 6,
                height: length,
                left: -3,
                top: 0,
                background: "linear-gradient(180deg, rgba(255,255,255,0.5), rgba(255,255,255,0.2))",
                borderRadius: 3,
                transform: `translate3d(${A.x * scale}px, ${A.y * scale}px, ${A.z * scale}px) rotateY(${yaw}deg) rotateX(${pitch + 90}deg) translateY(0px)`,
                transformOrigin: "top center",
                boxShadow: "0 0 8px rgba(255,255,255,0.3)",
              }}
            />
          );
        })}
        {m.atoms.map((a, i) => {
          const color = ELEMENT_COLORS[a.el] || "#fff";
          const size = a.el === "H" ? 28 : 42;
          return (
            <div
              key={i}
              style={{
                position: "absolute",
                left: -size / 2,
                top: -size / 2,
                width: size,
                height: size,
                borderRadius: "50%",
                background: `radial-gradient(circle at 30% 30%, white, ${color} 60%, ${color}55 100%)`,
                boxShadow: `0 0 24px ${color}aa, inset -6px -6px 12px rgba(0,0,0,0.35)`,
                transform: `translate3d(${a.x * scale}px, ${a.y * scale}px, ${a.z * scale}px)`,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                fontFamily: "JetBrains Mono",
                fontSize: a.el === "H" ? 10 : 13,
                color: a.el === "C" || a.el === "Fe" ? "#fff" : "#1a0a1f",
                fontWeight: 600,
                textShadow: "0 1px 1px rgba(0,0,0,0.2)",
              }}
            >
              {a.el}
            </div>
          );
        })}
      </motion.div>
      </div>
    </div>
  );
}

function ElementalDonut({
  data,
}: {
  data: { label: string; pct: number; color: string }[];
}) {
  const total = data.reduce((s, d) => s + d.pct, 0);
  let acc = 0;
  const stops = data
    .map((d) => {
      const start = (acc / total) * 360;
      acc += d.pct;
      const end = (acc / total) * 360;
      return `${d.color} ${start}deg ${end}deg`;
    })
    .join(", ");
  return (
    <div className="relative" style={{ width: 200, height: 200 }}>
      <div
        className="size-full rounded-full"
        style={{
          background: `conic-gradient(${stops})`,
          boxShadow: "0 0 40px rgba(124,92,255,0.3)",
        }}
      />
      <div
        className="glass absolute inset-6 flex items-center justify-center rounded-full"
        style={{ background: "rgba(11,14,26,0.85)" }}
      >
        <div className="text-center">
          <div
            className="font-mono"
            style={{ fontSize: 9, color: "rgba(255,255,255,0.5)", letterSpacing: "0.2em" }}
          >
            ELEMENTAL
          </div>
          <div className="font-heading" style={{ fontSize: 22 }}>
            Mix
          </div>
        </div>
      </div>
    </div>
  );
}

export function CompositionLab() {
  const [bodyIdx, setBodyIdx] = useState(5); // Jupiter
  const planet = PLANETS[bodyIdx];

  const availableMolecules = useMemo(
    () => MOLECULES.filter((m) => planet.molecules.includes(m.formula)),
    [planet]
  );
  const [molIdx, setMolIdx] = useState(0);
  const currentMolecule = availableMolecules[molIdx] || MOLECULES[0];
  const currentMolIdx = MOLECULES.findIndex((m) => m.formula === currentMolecule.formula);

  return (
    <section id="composition" className="relative px-6 py-32 lg:px-12">
      <div className="mx-auto max-w-[1400px]">
        <SectionHeading
          eyebrow="05 · COMPOSITION LAB"
          title="Down to the"
          emphasis="atom."
          body="Pick a body, see what it's made of, and rotate the molecules JWST detected in its skies."
        />

        <div className="mb-6 flex flex-wrap gap-2">
          {PLANETS.map((p, i) => (
            <button
              key={p.id}
              onClick={() => {
                setBodyIdx(i);
                setMolIdx(0);
              }}
              className="font-heading glass-pill px-3 py-1.5"
              style={{
                fontSize: 11,
                background:
                  bodyIdx === i
                    ? "linear-gradient(135deg, rgba(124,92,255,0.4), rgba(255,107,157,0.4))"
                    : "rgba(255,255,255,0.04)",
                border: "1px solid rgba(255,255,255,0.12)",
              }}
            >
              {p.symbol} {p.name}
            </button>
          ))}
        </div>

        <div className="grid gap-6 lg:grid-cols-[1fr_1fr_1.1fr]">
          <div className="glass glass-panel flex flex-col items-center gap-5 p-8">
            <div
              className="font-mono"
              style={{ fontSize: 10, letterSpacing: "0.22em", color: "var(--accent-helium)" }}
            >
              BODY
            </div>
            <Planet
              size={180}
              bg={planet.bg}
              ring={planet.ring}
              ringColor={planet.ringColor}
              ringTilt={planet.ringTilt}
              spin={32}
              glow={planet.color}
            />
            <div className="text-center">
              <div className="font-display" style={{ fontSize: 36, lineHeight: 1 }}>
                {planet.name}
              </div>
              <div
                className="font-mono mt-1.5"
                style={{ fontSize: 10, color: "rgba(255,255,255,0.5)", letterSpacing: "0.14em" }}
              >
                {planet.diameter.toUpperCase()}
              </div>
            </div>
          </div>

          <div className="glass glass-panel flex flex-col items-center gap-5 p-8">
            <div
              className="font-mono"
              style={{ fontSize: 10, letterSpacing: "0.22em", color: "var(--accent-stellar)" }}
            >
              ELEMENTS
            </div>
            <ElementalDonut data={planet.composition} />
            <div className="font-mono w-full space-y-1.5" style={{ fontSize: 11 }}>
              {planet.composition.map((c) => (
                <div key={c.label} className="flex items-center justify-between">
                  <span className="inline-flex items-center gap-2">
                    <span
                      className="inline-block size-2 rounded-full"
                      style={{ background: c.color, boxShadow: `0 0 6px ${c.color}` }}
                    />
                    {c.label}
                  </span>
                  <span style={{ color: "rgba(255,255,255,0.55)" }}>{c.pct}%</span>
                </div>
              ))}
            </div>
          </div>

          <div className="glass glass-panel flex flex-col gap-4 p-8">
            <div className="flex items-center justify-between">
              <div
                className="font-mono"
                style={{ fontSize: 10, letterSpacing: "0.22em", color: "var(--accent-gold)" }}
              >
                MOLECULES
              </div>
              <div className="font-mono" style={{ fontSize: 10, color: "rgba(255,255,255,0.4)" }}>
                DRAG TO ROTATE
              </div>
            </div>
            <div className="flex flex-wrap gap-2">
              {availableMolecules.map((m, i) => (
                <button
                  key={m.formula}
                  onClick={() => setMolIdx(i)}
                  className="font-heading glass-pill px-3 py-1.5"
                  style={{
                    fontSize: 12,
                    background:
                      i === molIdx
                        ? "linear-gradient(135deg, rgba(124,92,255,0.4), rgba(255,107,157,0.4))"
                        : "rgba(255,255,255,0.04)",
                    border: "1px solid rgba(255,255,255,0.12)",
                  }}
                >
                  {m.formula}
                </button>
              ))}
            </div>
            <Molecule3D moleculeIdx={currentMolIdx} />
            <div className="glass glass-card p-4">
              <div className="font-heading" style={{ fontSize: 18 }}>
                {currentMolecule.name} · {currentMolecule.formula}
              </div>
              <p
                className="mt-2"
                style={{ color: "var(--text-secondary)", fontSize: 13, lineHeight: 1.65 }}
              >
                {currentMolecule.note}
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
