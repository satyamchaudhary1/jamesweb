import { useMemo, useState } from "react";
import { AnimatePresence, motion } from "motion/react";
import { DEEP_SKY } from "./data";
import { SectionHeading } from "./SectionHeading";

const FILTERS = ["All", "Nebula", "Galaxy", "Star Cluster"] as const;

export function DeepSky() {
  const [filter, setFilter] = useState<typeof FILTERS[number]>("All");
  const [active, setActive] = useState<(typeof DEEP_SKY)[number] | null>(DEEP_SKY[0]);

  const visible = useMemo(
    () => DEEP_SKY.filter((d) => filter === "All" || d.type === filter),
    [filter]
  );

  return (
    <section id="deepsky" className="relative px-6 py-32 lg:px-12">
      <div className="mx-auto max-w-[1400px]">
        <SectionHeading
          eyebrow="03 · DEEP SKY EXPLORER"
          title="Pan across the"
          emphasis="ancient sky."
          body="Markers reveal nebulae, galaxies and star clusters Webb has resolved. Each one — a window through time."
        />

        <div className="mb-6 flex flex-wrap gap-2">
          {FILTERS.map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className="font-heading glass-pill px-4 py-2 transition-colors"
              style={{
                fontSize: 12,
                background:
                  filter === f
                    ? "linear-gradient(135deg, rgba(124,92,255,0.4), rgba(255,107,157,0.4))"
                    : "rgba(255,255,255,0.04)",
                border: "1px solid rgba(255,255,255,0.12)",
              }}
            >
              {f}
            </button>
          ))}
        </div>

        <div className="grid gap-6 lg:grid-cols-[1.6fr_1fr]">
          <div
            className="glass glass-panel relative overflow-hidden"
            style={{
              aspectRatio: "16/10",
              background:
                "radial-gradient(circle at 20% 30%, rgba(124,92,255,0.25), transparent 40%), radial-gradient(circle at 75% 70%, rgba(255,107,157,0.2), transparent 45%), #0a0d1c",
            }}
          >
            <div className="absolute inset-0 opacity-50" style={{ backgroundImage: "radial-gradient(rgba(255,255,255,0.6) 0.7px, transparent 0.8px), radial-gradient(rgba(255,255,255,0.4) 0.5px, transparent 0.6px)", backgroundSize: "40px 40px, 80px 80px", backgroundPosition: "0 0, 20px 20px" }} />

            {visible.map((d) => (
              <button
                key={d.id}
                onClick={() => setActive(d)}
                className="absolute -translate-x-1/2 -translate-y-1/2"
                style={{ left: `${d.x}%`, top: `${d.y}%` }}
              >
                <div className="relative">
                  <div
                    className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 rounded-full"
                    style={{
                      width: 36,
                      height: 36,
                      background:
                        d.type === "Nebula"
                          ? "radial-gradient(circle, rgba(255,107,157,0.5), transparent 65%)"
                          : d.type === "Galaxy"
                          ? "radial-gradient(circle, rgba(79,209,255,0.45), transparent 65%)"
                          : "radial-gradient(circle, rgba(255,181,71,0.5), transparent 65%)",
                      animation: "stellaris-pulse 3s ease-out infinite",
                    }}
                  />
                  <div
                    className="relative size-2.5 rounded-full"
                    style={{
                      background:
                        d.type === "Nebula" ? "#FF6B9D" : d.type === "Galaxy" ? "#4FD1FF" : "#FFB547",
                      boxShadow: `0 0 12px ${d.type === "Nebula" ? "#FF6B9D" : d.type === "Galaxy" ? "#4FD1FF" : "#FFB547"}`,
                      transform: active?.id === d.id ? "scale(1.6)" : "scale(1)",
                      transition: "transform 0.4s cubic-bezier(0.22,1,0.36,1)",
                    }}
                  />
                  {active?.id === d.id && (
                    <div
                      className="font-mono absolute left-1/2 top-full mt-2 -translate-x-1/2 whitespace-nowrap glass glass-pill px-2 py-1"
                      style={{ fontSize: 9, letterSpacing: "0.14em" }}
                    >
                      {d.name.toUpperCase()}
                    </div>
                  )}
                </div>
              </button>
            ))}
          </div>

          <div className="glass glass-panel flex flex-col gap-4 p-6">
            <AnimatePresence mode="wait">
              {active && (
                <motion.div
                  key={active.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.4 }}
                >
                  <div
                    className="font-mono"
                    style={{ fontSize: 10, letterSpacing: "0.2em", color: "var(--accent-helium)" }}
                  >
                    {active.type.toUpperCase()}
                  </div>
                  <div className="font-display mt-1" style={{ fontSize: 40, lineHeight: 1 }}>
                    {active.name}
                  </div>
                  <div
                    className="font-mono mt-3 inline-flex items-center gap-2 glass glass-pill px-3 py-1.5"
                    style={{ fontSize: 11 }}
                  >
                    <span style={{ color: "rgba(255,255,255,0.5)", letterSpacing: "0.14em" }}>
                      DISTANCE
                    </span>
                    <span>{active.distance}</span>
                  </div>
                  <p
                    className="mt-5"
                    style={{ color: "var(--text-secondary)", fontSize: 14, lineHeight: 1.7 }}
                  >
                    {active.note}
                  </p>

                  <div className="mt-6 grid grid-cols-3 gap-2">
                    {[
                      ["Mass", "—"],
                      ["Type", active.type],
                      ["Cataloged", "Yes"],
                    ].map(([k, v]) => (
                      <div
                        key={k}
                        className="glass glass-card px-3 py-2"
                        style={{ fontSize: 10 }}
                      >
                        <div
                          className="font-mono"
                          style={{ color: "rgba(255,255,255,0.45)", letterSpacing: "0.16em" }}
                        >
                          {k.toUpperCase()}
                        </div>
                        <div className="font-heading mt-1" style={{ fontSize: 13 }}>
                          {v}
                        </div>
                      </div>
                    ))}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </section>
  );
}
