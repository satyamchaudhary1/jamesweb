import { useState } from "react";
import { motion } from "motion/react";
import { EXOPLANETS } from "./data";
import { Planet } from "./Planet";
import { SectionHeading } from "./SectionHeading";

export function Exoplanets() {
  const [active, setActive] = useState(0);
  const p = EXOPLANETS[active];
  return (
    <section id="exoplanets" className="relative px-6 py-32 lg:px-12">
      <div className="mx-auto max-w-[1400px]">
        <SectionHeading
          eyebrow="04 · EXOPLANET LAB"
          title="Worlds beyond"
          emphasis="our sun."
          body="Webb tasted the atmosphere of a planet 700 light-years away. Compare any of these worlds against Earth."
        />

        <div className="grid gap-8 lg:grid-cols-[1fr_1.2fr]">
          <div className="glass glass-panel flex flex-col items-center justify-center gap-6 p-10">
            <div
              className="font-mono"
              style={{ fontSize: 10, letterSpacing: "0.22em", color: "var(--accent-helium)" }}
            >
              SUBJECT · {p.name.toUpperCase()}
            </div>
            <Planet size={220} bg={p.bg} spin={36} glow="#7C5CFF" />
            <div className="text-center">
              <div className="font-display" style={{ fontSize: 48, lineHeight: 1 }}>
                {p.name}
              </div>
              <div
                className="font-mono mt-2"
                style={{ fontSize: 11, color: "rgba(255,255,255,0.55)", letterSpacing: "0.14em" }}
              >
                {p.type.toUpperCase()} · {p.distance.toUpperCase()}
              </div>
            </div>
            <p
              className="max-w-[400px] text-center"
              style={{ color: "var(--text-secondary)", fontSize: 14, lineHeight: 1.7 }}
            >
              {p.blurb}
            </p>
          </div>

          <div className="flex flex-col gap-4">
            <div className="grid gap-4">
              {EXOPLANETS.map((ex, i) => (
                <motion.button
                  key={ex.id}
                  onClick={() => setActive(i)}
                  whileHover={{ x: 4 }}
                  className="glass glass-card flex items-center gap-5 p-5 text-left transition-colors"
                  style={{
                    border:
                      i === active
                        ? "1px solid rgba(124,92,255,0.5)"
                        : "1px solid rgba(255,255,255,0.12)",
                    background:
                      i === active
                        ? "linear-gradient(135deg, rgba(124,92,255,0.18), rgba(255,107,157,0.12))"
                        : "rgba(255,255,255,0.04)",
                  }}
                >
                  <Planet size={56} bg={ex.bg} spin={24} />
                  <div className="flex-1">
                    <div className="font-heading" style={{ fontSize: 18 }}>
                      {ex.name}
                    </div>
                    <div
                      className="font-mono mt-0.5"
                      style={{
                        fontSize: 10,
                        color: "rgba(255,255,255,0.5)",
                        letterSpacing: "0.14em",
                      }}
                    >
                      {ex.type.toUpperCase()} · {ex.distance.toUpperCase()}
                    </div>
                    <div className="mt-1.5" style={{ fontSize: 12, color: "rgba(255,255,255,0.6)" }}>
                      Temp {ex.temp}
                    </div>
                  </div>
                </motion.button>
              ))}
            </div>

            <div className="glass glass-panel p-6">
              <div
                className="font-mono mb-3"
                style={{ fontSize: 10, letterSpacing: "0.18em", color: "rgba(255,255,255,0.5)" }}
              >
                COMPARE TO EARTH
              </div>
              <div className="flex items-end justify-around gap-6">
                <div className="flex flex-col items-center gap-3">
                  <Planet
                    size={80}
                    bg="radial-gradient(circle at 30% 30%, #b8e6ff, #2c6cb8 55%, #0e2a5a)"
                    spin={20}
                    glow="#4FD1FF"
                  />
                  <div className="font-heading" style={{ fontSize: 14 }}>
                    Earth
                  </div>
                  <div className="font-mono" style={{ fontSize: 10, color: "rgba(255,255,255,0.5)" }}>
                    12,742 km
                  </div>
                </div>
                <div
                  className="font-display"
                  style={{ fontSize: 28, color: "rgba(255,255,255,0.4)" }}
                >
                  vs
                </div>
                <div className="flex flex-col items-center gap-3">
                  <Planet size={p.id === "wasp39b" ? 130 : 70} bg={p.bg} spin={22} glow="#7C5CFF" />
                  <div className="font-heading" style={{ fontSize: 14 }}>
                    {p.name}
                  </div>
                  <div className="font-mono" style={{ fontSize: 10, color: "rgba(255,255,255,0.5)" }}>
                    {p.id === "wasp39b" ? "~1.27× Jupiter" : "~Earth-sized"}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
