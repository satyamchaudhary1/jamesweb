import { useState } from "react";
import { ArrowRight } from "lucide-react";

export function Footer() {
  const [email, setEmail] = useState("");
  const [done, setDone] = useState(false);
  return (
    <footer className="relative px-6 pb-16 pt-24 lg:px-12">
      <div className="mx-auto max-w-[1400px]">
        <div className="glass glass-panel grid gap-10 p-10 lg:grid-cols-[1.3fr_1fr] lg:p-14">
          <div>
            <div
              className="font-mono mb-4 inline-flex items-center gap-2"
              style={{ fontSize: 11, letterSpacing: "0.22em", color: "var(--accent-gold)" }}
            >
              <span
                className="inline-block size-1.5 rounded-full"
                style={{ background: "var(--accent-gold)", boxShadow: "0 0 8px var(--accent-gold)" }}
              />
              STAY IN ORBIT
            </div>
            <h3 className="font-display" style={{ fontSize: "clamp(36px, 4vw, 56px)", lineHeight: 1 }}>
              Get notified when Webb releases <em className="cosmos-gradient-text">a new image.</em>
            </h3>
            <p
              className="mt-4 max-w-[440px]"
              style={{ color: "var(--text-secondary)", fontSize: 15, lineHeight: 1.65 }}
            >
              One email per major release. No marketing. No spam. Just the universe, in higher resolution.
            </p>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                if (email) setDone(true);
              }}
              className="mt-7 flex max-w-[440px] flex-col gap-2 sm:flex-row"
            >
              <input
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                type="email"
                placeholder="you@stars.io"
                required
                className="glass glass-pill flex-1 px-5 py-3 outline-none"
                style={{ fontSize: 14, background: "rgba(255,255,255,0.04)" }}
              />
              <button
                className="font-heading glass-pill inline-flex items-center justify-center gap-2 px-6 py-3"
                style={{
                  background: "linear-gradient(135deg, #7C5CFF, #FF6B9D)",
                  boxShadow: "0 8px 24px rgba(124,92,255,0.4)",
                  fontSize: 13,
                }}
              >
                {done ? "Subscribed ✓" : "Subscribe"} {!done && <ArrowRight size={14} />}
              </button>
            </form>
          </div>

          <div className="grid grid-cols-2 gap-6">
            {[
              {
                title: "Sections",
                links: [
                  ["Mission", "#hero"],
                  ["Gallery", "#gallery"],
                  ["Orrery", "#orrery"],
                  ["Deep Sky", "#deepsky"],
                  ["Exoplanets", "#exoplanets"],
                  ["Composition", "#composition"],
                  ["Timeline", "#timeline"],
                  ["JWST", "#telescope"],
                ],
              },
              {
                title: "Credits",
                links: [
                  ["NASA/ESA/CSA", "#"],
                  ["STScI", "#"],
                  ["JWST Science Team", "#"],
                  ["Unsplash imagery", "#"],
                ],
              },
            ].map((g) => (
              <div key={g.title}>
                <div
                  className="font-mono mb-3"
                  style={{ fontSize: 10, letterSpacing: "0.22em", color: "rgba(255,255,255,0.5)" }}
                >
                  {g.title.toUpperCase()}
                </div>
                <ul className="space-y-2">
                  {g.links.map(([label, href]) => (
                    <li key={label}>
                      <a
                        href={href}
                        className="transition-colors hover:text-white"
                        style={{ fontSize: 13, color: "rgba(255,255,255,0.65)" }}
                      >
                        {label}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>

        <div
          className="font-mono mt-10 flex flex-col items-center justify-between gap-3 sm:flex-row"
          style={{ fontSize: 10, color: "rgba(255,255,255,0.4)", letterSpacing: "0.18em" }}
        >
          <div>STELLARIS · A TRIBUTE TO THE JAMES WEBB SPACE TELESCOPE</div>
          <div>L2 · −233 °C · 1.5M KM · STILL OBSERVING</div>
        </div>
      </div>
    </footer>
  );
}
