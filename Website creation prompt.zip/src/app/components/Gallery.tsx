import { useState } from "react";
import { AnimatePresence, motion } from "motion/react";
import { X, ZoomIn, Calendar, Telescope, Ruler } from "lucide-react";
import { JWST_IMAGES, type JWSTImage } from "./data";
import { SectionHeading } from "./SectionHeading";
import { ImageWithFallback } from "./figma/ImageWithFallback";

function Card({ img, onOpen }: { img: JWSTImage; onOpen: () => void }) {
  const [hover, setHover] = useState(false);
  return (
    <motion.button
      type="button"
      onClick={onOpen}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      whileHover={{ rotateX: -3, rotateY: 6, scale: 1.02 }}
      transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
      className={`glass glass-card relative block w-full overflow-hidden text-left ${
        img.span === 2 ? "lg:col-span-2" : ""
      }`}
      style={{
        aspectRatio: img.span === 2 ? "16/9" : "4/5",
        transformStyle: "preserve-3d",
        cursor: "pointer",
      }}
    >
      <ImageWithFallback
        src={img.url}
        alt={img.alt}
        className="absolute inset-0 size-full object-cover transition-transform duration-700"
        style={{ transform: hover ? "scale(1.08)" : "scale(1)" }}
      />
      <div
        className="pointer-events-none absolute inset-0"
        style={{
          background: "linear-gradient(180deg, transparent 40%, rgba(5,6,10,0.85) 100%)",
        }}
      />
      <div className="absolute right-4 top-4">
        <div
          className="font-mono glass glass-pill px-2.5 py-1"
          style={{ fontSize: 10, letterSpacing: "0.12em" }}
        >
          {img.distance}
        </div>
      </div>

      <AnimatePresence>
        {hover && (
          <motion.div
            initial={{ y: 60, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 60, opacity: 0 }}
            transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
            className="absolute inset-x-4 bottom-4"
          >
            <div className="glass glass-card p-4">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div
                    className="font-display"
                    style={{ fontSize: 26, lineHeight: 1.1 }}
                  >
                    {img.title}
                  </div>
                  <div
                    className="font-mono mt-1"
                    style={{ fontSize: 11, color: "rgba(255,255,255,0.6)", letterSpacing: "0.08em" }}
                  >
                    {img.subtitle}
                  </div>
                </div>
                <div
                  className="glass-pill flex size-9 items-center justify-center"
                  style={{
                    background: "linear-gradient(135deg, #7C5CFF, #FF6B9D)",
                  }}
                >
                  <ZoomIn size={14} />
                </div>
              </div>
              <div
                className="font-mono mt-3 flex gap-4"
                style={{ fontSize: 10, color: "rgba(255,255,255,0.55)", letterSpacing: "0.1em" }}
              >
                <span className="inline-flex items-center gap-1">
                  <Calendar size={10} /> {img.date}
                </span>
                <span className="inline-flex items-center gap-1">
                  <Telescope size={10} /> {img.filter.split(" · ")[0]}
                </span>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.button>
  );
}

function Viewer({ img, onClose }: { img: JWSTImage; onClose: () => void }) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.4 }}
      className="fixed inset-0 z-[80] flex items-center justify-center p-6"
      style={{ background: "rgba(5,6,10,0.85)", backdropFilter: "blur(14px)" }}
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.95, opacity: 0 }}
        transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
        onClick={(e) => e.stopPropagation()}
        className="glass glass-panel relative grid w-full max-w-[1280px] grid-cols-1 overflow-hidden lg:grid-cols-[1.6fr_1fr]"
        style={{ maxHeight: "88vh" }}
      >
        <div className="relative" style={{ minHeight: 320 }}>
          <ImageWithFallback src={img.url} alt={img.alt} className="size-full object-cover" />
        </div>
        <div className="flex flex-col gap-5 p-8 lg:p-10">
          <div
            className="font-mono inline-flex items-center gap-2"
            style={{ fontSize: 10, letterSpacing: "0.22em", color: "var(--accent-helium)" }}
          >
            <span
              className="inline-block size-1.5 rounded-full"
              style={{ background: "var(--accent-helium)", boxShadow: "0 0 8px var(--accent-helium)" }}
            />
            JWST · IMMERSIVE VIEW
          </div>
          <div>
            <div className="font-display" style={{ fontSize: 56, lineHeight: 1 }}>
              {img.title}
            </div>
            <div
              className="font-heading mt-2"
              style={{ fontSize: 16, color: "rgba(255,255,255,0.72)" }}
            >
              {img.subtitle}
            </div>
          </div>

          <div className="font-mono grid gap-2" style={{ fontSize: 11 }}>
            <div className="glass glass-card flex items-center justify-between px-4 py-3">
              <span style={{ color: "rgba(255,255,255,0.5)", letterSpacing: "0.14em" }}>
                <Calendar size={12} className="mr-2 inline" />
                CAPTURED
              </span>
              <span>{img.date}</span>
            </div>
            <div className="glass glass-card flex items-center justify-between px-4 py-3">
              <span style={{ color: "rgba(255,255,255,0.5)", letterSpacing: "0.14em" }}>
                <Telescope size={12} className="mr-2 inline" />
                INSTRUMENT
              </span>
              <span>{img.filter}</span>
            </div>
            <div className="glass glass-card flex items-center justify-between px-4 py-3">
              <span style={{ color: "rgba(255,255,255,0.5)", letterSpacing: "0.14em" }}>
                <Ruler size={12} className="mr-2 inline" />
                DISTANCE
              </span>
              <span>{img.distance}</span>
            </div>
          </div>

          <p style={{ color: "var(--text-secondary)", fontSize: 14, lineHeight: 1.7 }}>
            {img.alt}
          </p>

          <div className="mt-auto flex justify-between">
            <div className="font-mono" style={{ fontSize: 10, color: "rgba(255,255,255,0.4)" }}>
              ESC to exit
            </div>
            <button
              onClick={onClose}
              className="glass glass-pill inline-flex items-center gap-2 px-4 py-2"
              style={{ fontSize: 12 }}
            >
              <X size={14} /> Close
            </button>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}

export function Gallery() {
  const [open, setOpen] = useState<JWSTImage | null>(null);

  return (
    <section id="gallery" className="relative px-6 py-32 lg:px-12">
      <div className="mx-auto max-w-[1400px]">
        <SectionHeading
          eyebrow="01 · JWST GALLERY"
          title="The"
          emphasis="masterpieces."
          body="Twelve frames that redefined what we thought light could tell us. Hover for context. Click to step inside."
        />
        <div className="grid grid-cols-1 gap-5 md:grid-cols-2 lg:grid-cols-3">
          {JWST_IMAGES.map((img) => (
            <Card key={img.title} img={img} onOpen={() => setOpen(img)} />
          ))}
        </div>
      </div>
      <AnimatePresence>
        {open && <Viewer img={open} onClose={() => setOpen(null)} />}
      </AnimatePresence>
    </section>
  );
}
