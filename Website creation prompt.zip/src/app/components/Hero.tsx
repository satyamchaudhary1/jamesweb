import { motion } from "motion/react";
import { ArrowRight, Play } from "lucide-react";
import { JWSTModel } from "./JWSTModel";

export function Hero() {
  return (
    <section
      id="hero"
      className="relative flex min-h-screen items-center justify-center overflow-hidden px-8 pt-24"
    >
      <div className="relative z-10 mx-auto grid w-full max-w-[1400px] grid-cols-1 items-center gap-12 lg:grid-cols-[1.1fr_1fr]">
        <div>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2, duration: 1, ease: [0.22, 1, 0.36, 1] }}
            className="glass glass-pill mb-6 inline-flex items-center gap-2 px-4 py-1.5"
            style={{ fontSize: 11, letterSpacing: "0.22em" }}
          >
            <span
              className="inline-block size-1.5 rounded-full"
              style={{ background: "var(--accent-helium)", boxShadow: "0 0 8px var(--accent-helium)" }}
            />
            <span className="font-mono" style={{ color: "rgba(255,255,255,0.72)" }}>
              MISSION ACTIVE · L2 ORBIT
            </span>
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4, duration: 1.2, ease: [0.22, 1, 0.36, 1] }}
            className="font-display"
            style={{ fontSize: "clamp(56px, 9vw, 132px)", lineHeight: 0.95 }}
          >
            Look <em className="cosmos-gradient-text">closer</em>
            <br />
            at the universe.
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.7, duration: 1 }}
            className="mt-6 max-w-[520px]"
            style={{ color: "var(--text-secondary)", fontSize: 17, lineHeight: 1.6 }}
          >
            Every image. Every world. Every atom. Captured by the James Webb Space Telescope —
            and rendered here as a console you can touch.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.9, duration: 1 }}
            className="mt-10 flex flex-wrap items-center gap-3"
          >
            <a
              href="#gallery"
              className="font-heading glass-pill group inline-flex items-center gap-2 px-6 py-3 transition-transform hover:scale-[1.02]"
              style={{
                background: "linear-gradient(135deg, #7C5CFF 0%, #FF6B9D 100%)",
                boxShadow: "0 8px 32px rgba(124,92,255,0.45), inset 0 1px 0 rgba(255,255,255,0.25)",
                fontSize: 14,
              }}
            >
              Explore Gallery
              <ArrowRight size={16} className="transition-transform group-hover:translate-x-0.5" />
            </a>
            <a
              href="#orrery"
              className="font-heading glass glass-pill inline-flex items-center gap-2 px-6 py-3 transition-colors hover:bg-white/10"
              style={{ fontSize: 14 }}
            >
              <Play size={14} fill="currentColor" />
              Launch Tour
            </a>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.2, duration: 1 }}
            className="font-mono mt-14 grid grid-cols-2 gap-x-8 gap-y-3 md:grid-cols-4"
            style={{ fontSize: 11, color: "rgba(255,255,255,0.6)" }}
          >
            {[
              ["1.5M km", "FROM EARTH"],
              ["6.5 m", "MIRROR"],
              ["−233 °C", "INSTRUMENT TEMP"],
              ["13.6 B yrs", "OBSERVED"],
            ].map(([v, l]) => (
              <div key={l}>
                <div style={{ color: "white", fontSize: 18, letterSpacing: "-0.01em" }}>{v}</div>
                <div className="mt-1" style={{ letterSpacing: "0.16em" }}>
                  {l}
                </div>
              </div>
            ))}
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.5, duration: 1.4, ease: [0.22, 1, 0.36, 1] }}
          className="relative mx-auto aspect-square w-full max-w-[360px]"
        >
          <JWSTModel />
        </motion.div>
      </div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.6, duration: 1 }}
        className="font-mono absolute bottom-6 left-1/2 -translate-x-1/2"
        style={{ fontSize: 10, color: "rgba(255,255,255,0.4)", letterSpacing: "0.3em" }}
      >
        SCROLL TO DESCEND ↓
      </motion.div>
    </section>
  );
}
