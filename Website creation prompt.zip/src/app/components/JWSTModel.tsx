import { Component, Suspense, useRef, type ReactNode } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { OrbitControls, useGLTF, Bounds } from "@react-three/drei";
import type { Group } from "three";
import jwstBase64 from "../../assets/jwstModelData";

function base64ToBlobUrl(b64: string): string {
  const bin = atob(b64);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return URL.createObjectURL(new Blob([bytes], { type: "model/gltf-binary" }));
}

const MODEL_URL = base64ToBlobUrl(jwstBase64);

useGLTF.preload(MODEL_URL, true);

function Telescope() {
  const ref = useRef<Group>(null);
  const { scene } = useGLTF(MODEL_URL, true);

  useFrame((_, delta) => {
    if (ref.current) ref.current.rotation.y += delta * 0.15;
  });

  return (
    <group rotation={[0.2, 0, 0]}>
      <group ref={ref}>
        <primitive object={scene} />
      </group>
    </group>
  );
}

function Fallback() {
  return (
    <mesh>
      <icosahedronGeometry args={[0.6, 1]} />
      <meshStandardMaterial color="#FFB547" emissive="#FF6B9D" emissiveIntensity={0.3} wireframe />
    </mesh>
  );
}

class CanvasErrorBoundary extends Component<{ children: ReactNode }, { errored: boolean }> {
  state = { errored: false };
  static getDerivedStateFromError() {
    return { errored: true };
  }
  componentDidCatch(err: unknown) {
    console.warn("[JWSTModel] failed to render:", err);
  }
  render() {
    if (this.state.errored) {
      return (
        <div
          className="flex size-full items-center justify-center font-mono"
          style={{ fontSize: 10, color: "rgba(255,255,255,0.4)", letterSpacing: "0.18em" }}
        >
          MODEL OFFLINE
        </div>
      );
    }
    return this.props.children;
  }
}

export function JWSTModel() {
  return (
    <div className="relative size-full">
      <CanvasErrorBoundary>
        <Canvas
          camera={{ position: [0, 0.4, 4.2], fov: 42 }}
          dpr={[1, 2]}
          gl={{ antialias: true, alpha: true }}
          style={{ background: "transparent" }}
        >
          <ambientLight intensity={0.35} />
          <directionalLight position={[5, 4, 6]} intensity={1.4} color="#FFE6B0" />
          <directionalLight position={[-4, -2, -3]} intensity={0.5} color="#7C5CFF" />
          <pointLight position={[0, 0, 4]} intensity={0.6} color="#FF6B9D" />

          <Suspense fallback={<Fallback />}>
            <Bounds fit clip margin={1.15}>
              <Telescope />
            </Bounds>
          </Suspense>

          <OrbitControls
            enableZoom={false}
            enablePan={false}
            autoRotate={false}
            minPolarAngle={Math.PI / 3}
            maxPolarAngle={Math.PI / 1.6}
          />
        </Canvas>
      </CanvasErrorBoundary>
    </div>
  );
}
