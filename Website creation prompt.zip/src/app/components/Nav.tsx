import { useEffect, useState } from "react";
import { motion } from "motion/react";

const SECTIONS = [
  { id: "hero", label: "Mission" },
  { id: "gallery", label: "Gallery" },
  { id: "orrery", label: "Orrery" },
  { id: "deepsky", label: "Deep Sky" },
  { id: "exoplanets", label: "Exoplanets" },
  { id: "composition", label: "Composition" },
  { id: "timeline", label: "Timeline" },
  { id: "telescope", label: "JWST" },
];

export function Nav() {
  const [active, setActive] = useState("hero");

  useEffect(() => {
    const onScroll = () => {
      let current = "hero";
      for (const s of SECTIONS) {
        const el = document.getElementById(s.id);
        if (el && el.getBoundingClientRect().top < window.innerHeight * 0.4) {
          current = s.id;
        }
      }
      setActive(current);
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    onScroll();
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <motion.nav
      initial={{ y: -40, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ delay: 0.3, duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
      className="fixed left-1/2 top-6 z-50 -translate-x-1/2"
    >
      <div className="glass glass-pill flex items-center gap-1 px-2 py-1.5">
        <div
          className="font-heading mr-2 ml-2 flex items-center gap-2"
          style={{ fontSize: 13, letterSpacing: "0.18em" }}
        >
          <span
            className="inline-block size-2 rounded-full"
            style={{ background: "var(--accent-gold)", boxShadow: "0 0 8px var(--accent-gold)" }}
          />
          STELLARIS
        </div>
        {SECTIONS.map((s) => (
          <a
            key={s.id}
            href={`#${s.id}`}
            className="font-heading glass-pill relative px-3 py-1.5 transition-colors"
            style={{
              fontSize: 12,
              letterSpacing: "0.04em",
              color: active === s.id ? "white" : "rgba(255,255,255,0.55)",
            }}
          >
            {active === s.id && (
              <motion.span
                layoutId="nav-pill"
                className="glass-pill absolute inset-0 -z-10"
                style={{
                  background:
                    "linear-gradient(135deg, rgba(124,92,255,0.4), rgba(255,107,157,0.4))",
                  border: "1px solid rgba(255,255,255,0.2)",
                }}
                transition={{ type: "spring", stiffness: 380, damping: 30 }}
              />
            )}
            {s.label}
          </a>
        ))}
      </div>
    </motion.nav>
  );
}
