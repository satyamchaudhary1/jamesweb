import { useState } from "react";
import { AnimatePresence, motion } from "motion/react";
import { X, ChevronRight, Sparkles } from "lucide-react";
import { PLANETS, type Planet as PlanetType } from "./data";
import { Planet } from "./Planet";
import { SectionHeading } from "./SectionHeading";

const TABS = ["Overview", "Composition", "Atmosphere", "JWST View"] as const;

function DetailPanel({ planet, onClose }: { planet: PlanetType; onClose: () => void }) {
  const [tab, setTab] = useState<typeof TABS[number]>("Overview");
  return (
    <motion.aside
      initial={{ x: 520, opacity: 0 }}
      animate={{ x: 0, opacity: 1 }}
      exit={{ x: 520, opacity: 0 }}
      transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
      className="glass glass-panel fixed right-6 top-24 z-[70] flex w-[460px] max-w-[90vw] flex-col overflow-hidden"
      style={{ maxHeight: "calc(100vh - 7rem)" }}
    >
      <div className="relative h-[180px] overflow-hidden">
        <div
          className="absolute inset-0"
          style={{
            background: planet.bg,
            filter: "blur(20px)",
            transform: "scale(1.4)",
            opacity: 0.6,
          }}
        />
        <div className="absolute inset-0 flex items-center justify-center">
          <Planet
            size={140}
            bg={planet.bg}
            ring={planet.ring}
            ringColor={planet.ringColor}
            ringTilt={planet.ringTilt}
            spin={40}
            glow={planet.color}
          />
        </div>
        <button
          onClick={onClose}
          className="glass glass-pill absolute right-4 top-4 flex size-9 items-center justify-center"
          aria-label="Close"
        >
          <X size={14} />
        </button>
      </div>

      <div className="px-6 pt-5">
        <div
          className="font-mono"
          style={{ fontSize: 10, letterSpacing: "0.2em", color: "var(--accent-helium)" }}
        >
          {planet.symbol} · CELESTIAL BODY
        </div>
        <div className="font-display mt-1" style={{ fontSize: 46, lineHeight: 1 }}>
          {planet.name}
        </div>
        <p className="mt-3" style={{ color: "var(--text-secondary)", fontSize: 14, lineHeight: 1.65 }}>
          {planet.blurb}
        </p>
      </div>

      <div className="mt-5 flex gap-1 px-6">
        {TABS.map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className="font-heading glass-pill relative px-3 py-1.5 transition-colors"
            style={{
              fontSize: 11,
              letterSpacing: "0.04em",
              color: tab === t ? "white" : "rgba(255,255,255,0.5)",
              background: tab === t ? "rgba(255,255,255,0.08)" : "transparent",
              border: tab === t ? "1px solid rgba(255,255,255,0.18)" : "1px solid transparent",
            }}
          >
            {t}
          </button>
        ))}
      </div>

      <div className="stellaris-scrollbar mt-4 flex-1 overflow-y-auto px-6 pb-6">
        <AnimatePresence mode="wait">
          <motion.div
            key={tab}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.3 }}
            className="space-y-3"
          >
            {tab === "Overview" && (
              <div className="font-mono space-y-2" style={{ fontSize: 11 }}>
                {[
                  ["DIAMETER", planet.diameter],
                  ["DISTANCE", planet.distance],
                  ["DAY", planet.day],
                  ["YEAR", planet.year],
                  ["TEMP", planet.temp],
                ].map(([k, v]) => (
                  <div
                    key={k}
                    className="glass glass-card flex items-start justify-between gap-3 px-4 py-3"
                  >
                    <span style={{ color: "rgba(255,255,255,0.5)", letterSpacing: "0.16em" }}>{k}</span>
                    <span className="text-right">{v}</span>
                  </div>
                ))}
              </div>
            )}
            {tab === "Composition" && (
              <div>
                <div className="glass glass-card p-4">
                  <div
                    className="font-mono mb-3"
                    style={{ fontSize: 10, letterSpacing: "0.18em", color: "rgba(255,255,255,0.5)" }}
                  >
                    ELEMENTAL BREAKDOWN
                  </div>
                  <div className="flex h-2.5 w-full overflow-hidden rounded-full" style={{ background: "rgba(255,255,255,0.08)" }}>
                    {planet.composition.map((c) => (
                      <div
                        key={c.label}
                        style={{
                          width: `${c.pct}%`,
                          background: c.color,
                          boxShadow: `inset 0 1px 0 rgba(255,255,255,0.3)`,
                        }}
                      />
                    ))}
                  </div>
                  <div className="font-mono mt-4 space-y-2" style={{ fontSize: 11 }}>
                    {planet.composition.map((c) => (
                      <div key={c.label} className="flex items-center justify-between">
                        <span className="flex items-center gap-2">
                          <span
                            className="inline-block size-2 rounded-full"
                            style={{ background: c.color, boxShadow: `0 0 6px ${c.color}` }}
                          />
                          {c.label}
                        </span>
                        <span style={{ color: "rgba(255,255,255,0.6)" }}>{c.pct}%</span>
                      </div>
                    ))}
                  </div>
                </div>
                <a
                  href="#composition"
                  className="glass-pill mt-3 flex items-center justify-between px-4 py-3"
                  style={{
                    background: "linear-gradient(135deg, rgba(124,92,255,0.3), rgba(255,107,157,0.3))",
                    border: "1px solid rgba(255,255,255,0.18)",
                  }}
                >
                  <span className="inline-flex items-center gap-2 font-heading" style={{ fontSize: 13 }}>
                    <Sparkles size={14} /> See molecules
                  </span>
                  <ChevronRight size={14} />
                </a>
              </div>
            )}
            {tab === "Atmosphere" && (
              <div className="glass glass-card p-4" style={{ fontSize: 14, lineHeight: 1.7 }}>
                <div
                  className="font-mono mb-2"
                  style={{ fontSize: 10, letterSpacing: "0.18em", color: "rgba(255,255,255,0.5)" }}
                >
                  SURFACE / ATMOSPHERE
                </div>
                {planet.surface}
              </div>
            )}
            {tab === "JWST View" && (
              <div className="glass glass-card p-4" style={{ fontSize: 14, lineHeight: 1.7 }}>
                <div
                  className="font-mono mb-2 inline-flex items-center gap-2"
                  style={{ fontSize: 10, letterSpacing: "0.18em", color: "var(--accent-gold)" }}
                >
                  <span
                    className="inline-block size-1.5 rounded-full"
                    style={{ background: "var(--accent-gold)", boxShadow: "0 0 8px var(--accent-gold)" }}
                  />
                  WEBB OBSERVATION
                </div>
                {planet.jwst}
              </div>
            )}
          </motion.div>
        </AnimatePresence>
      </div>
    </motion.aside>
  );
}

function OrbitDot({ planet, onClick }: { planet: PlanetType; onClick: () => void }) {
  const [hover, setHover] = useState(false);
  return (
    <div
      className="absolute left-1/2 top-1/2"
      style={{
        width: planet.orbit * 2,
        height: planet.orbit * 2,
        marginLeft: -planet.orbit,
        marginTop: -planet.orbit,
        borderRadius: "50%",
        border: "1px dashed rgba(255,255,255,0.08)",
        animation: `stellaris-spin ${planet.speed * 3}s linear infinite`,
      }}
    >
      <button
        type="button"
        onClick={onClick}
        onMouseEnter={() => setHover(true)}
        onMouseLeave={() => setHover(false)}
        className="absolute left-1/2 top-0 -translate-x-1/2 -translate-y-1/2 cursor-pointer"
        style={{ animation: `stellaris-spin-rev ${planet.speed * 3}s linear infinite` }}
      >
        <Planet
          size={planet.size}
          bg={planet.bg}
          ring={planet.ring}
          ringColor={planet.ringColor}
          ringTilt={planet.ringTilt}
          spin={planet.speed * 2}
          glow={planet.color}
          style={{ transform: hover ? "scale(1.15)" : "scale(1)", transition: "transform 0.3s" }}
        />
        <AnimatePresence>
          {hover && (
            <motion.div
              initial={{ opacity: 0, y: 4 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 4 }}
              transition={{ duration: 0.2 }}
              className="glass glass-card pointer-events-none absolute left-1/2 top-full mt-3 -translate-x-1/2 whitespace-nowrap px-3 py-2 text-left"
            >
              <div className="font-heading" style={{ fontSize: 12 }}>
                {planet.name}
              </div>
              <div
                className="font-mono mt-1"
                style={{ fontSize: 9, color: "rgba(255,255,255,0.55)", letterSpacing: "0.1em" }}
              >
                {planet.diameter} · {planet.day}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </button>
    </div>
  );
}

export function Orrery() {
  const [selected, setSelected] = useState<PlanetType | null>(null);
  const [scale, setScale] = useState<"Visible" | "Realistic">("Visible");
  const sun = PLANETS[0];

  return (
    <section id="orrery" className="relative px-6 py-32 lg:px-12">
      <div className="mx-auto max-w-[1400px]">
        <SectionHeading
          eyebrow="02 · ORRERY"
          title="A solar system you can"
          emphasis="touch."
          body="Hover any world for its vitals. Click to descend into its atmosphere."
        />
        <div className="mb-8 flex flex-wrap items-center gap-3">
          {(["Visible", "Realistic"] as const).map((s) => (
            <button
              key={s}
              onClick={() => setScale(s)}
              className="font-heading glass-pill px-4 py-2 transition-colors"
              style={{
                fontSize: 12,
                background: scale === s ? "linear-gradient(135deg, rgba(124,92,255,0.4), rgba(255,107,157,0.4))" : "rgba(255,255,255,0.04)",
                border: "1px solid rgba(255,255,255,0.12)",
              }}
            >
              {s} scale
            </button>
          ))}
          <span
            className="font-mono ml-2"
            style={{ fontSize: 10, color: "rgba(255,255,255,0.4)", letterSpacing: "0.16em" }}
          >
            REAL SCALE WOULD RENDER EARTH AS A SUB-PIXEL
          </span>
        </div>

        <div
          className="glass glass-panel relative mx-auto overflow-hidden"
          style={{
            aspectRatio: "16/9",
            maxWidth: 1400,
            background: "radial-gradient(ellipse at center, rgba(255,181,71,0.08), transparent 60%)",
          }}
        >
          <div
            className="relative size-full"
            style={{
              transform: scale === "Realistic" ? "scale(0.6)" : "scale(1)",
              transition: "transform 0.8s cubic-bezier(0.22, 1, 0.36, 1)",
            }}
          >
            <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
              <button onClick={() => setSelected(sun)} className="block cursor-pointer">
                <Planet size={sun.size} bg={sun.bg} spin={120} glow="#FFB547" />
              </button>
            </div>
            {PLANETS.slice(1).map((p) => (
              <OrbitDot key={p.id} planet={p} onClick={() => setSelected(p)} />
            ))}
          </div>
        </div>
      </div>

      <AnimatePresence>
        {selected && <DetailPanel planet={selected} onClose={() => setSelected(null)} />}
      </AnimatePresence>
    </section>
  );
}
