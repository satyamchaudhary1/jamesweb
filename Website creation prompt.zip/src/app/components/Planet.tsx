import { motion } from "motion/react";
import type { CSSProperties } from "react";

export function Planet({
  size,
  bg,
  ring,
  ringColor,
  ringTilt,
  spin = 60,
  glow,
  style,
}: {
  size: number;
  bg: string;
  ring?: boolean;
  ringColor?: string;
  ringTilt?: number;
  spin?: number;
  glow?: string;
  style?: CSSProperties;
}) {
  return (
    <div
      className="relative flex items-center justify-center"
      style={{ width: size, height: size, ...style }}
    >
      {glow && (
        <div
          className="pointer-events-none absolute inset-0 rounded-full"
          style={{
            background: `radial-gradient(circle, ${glow} 0%, transparent 65%)`,
            filter: "blur(20px)",
            transform: "scale(1.6)",
          }}
        />
      )}
      {ring && (
        <div
          className="pointer-events-none absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 rounded-full"
          style={{
            width: size * 2.1,
            height: size * 0.36,
            border: `1px solid ${ringColor || "rgba(255,255,255,0.4)"}`,
            background: `linear-gradient(180deg, transparent 0%, ${ringColor || "rgba(255,255,255,0.2)"} 50%, transparent 100%)`,
            transform: `rotate(${ringTilt ?? 18}deg)`,
            boxShadow: `0 0 16px ${ringColor || "rgba(255,255,255,0.3)"}`,
          }}
        />
      )}
      <motion.div
        animate={{ rotate: 360 }}
        transition={{ duration: spin, repeat: Infinity, ease: "linear" }}
        className="relative rounded-full"
        style={{
          width: size,
          height: size,
          background: bg,
          boxShadow: `inset -${size * 0.18}px -${size * 0.12}px ${size * 0.3}px rgba(0,0,0,0.55), inset ${size * 0.06}px ${size * 0.04}px ${size * 0.2}px rgba(255,255,255,0.1)`,
        }}
      >
        <div
          className="pointer-events-none absolute inset-0 rounded-full"
          style={{
            background:
              "radial-gradient(circle at 30% 25%, rgba(255,255,255,0.35) 0%, transparent 35%)",
          }}
        />
      </motion.div>
    </div>
  );
}
