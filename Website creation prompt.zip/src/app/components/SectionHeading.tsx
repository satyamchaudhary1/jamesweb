export function SectionHeading({
  eyebrow,
  title,
  emphasis,
  body,
}: {
  eyebrow: string;
  title: string;
  emphasis?: string;
  body?: string;
}) {
  return (
    <div className="mb-12 max-w-[760px]">
      <div
        className="font-mono mb-4 inline-flex items-center gap-2"
        style={{ fontSize: 11, letterSpacing: "0.22em", color: "var(--accent-helium)" }}
      >
        <span
          className="inline-block size-1.5 rounded-full"
          style={{ background: "var(--accent-helium)", boxShadow: "0 0 8px var(--accent-helium)" }}
        />
        {eyebrow}
      </div>
      <h2
        className="font-display"
        style={{ fontSize: "clamp(40px, 6vw, 84px)", lineHeight: 1, letterSpacing: "-0.02em" }}
      >
        {title}{" "}
        {emphasis && <em className="cosmos-gradient-text">{emphasis}</em>}
      </h2>
      {body && (
        <p
          className="mt-5 max-w-[600px]"
          style={{ color: "var(--text-secondary)", fontSize: 16, lineHeight: 1.6 }}
        >
          {body}
        </p>
      )}
    </div>
  );
}
