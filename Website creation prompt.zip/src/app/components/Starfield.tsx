import { useMemo } from "react";

type Star = { x: number; y: number; size: number; delay: number; duration: number; layer: number };

export function Starfield({ density = 180 }: { density?: number }) {
  const stars = useMemo<Star[]>(() => {
    const arr: Star[] = [];
    for (let i = 0; i < density; i++) {
      arr.push({
        x: Math.random() * 100,
        y: Math.random() * 100,
        size: Math.random() * 2 + 0.4,
        delay: Math.random() * 6,
        duration: 3 + Math.random() * 6,
        layer: Math.floor(Math.random() * 3),
      });
    }
    return arr;
  }, [density]);

  return (
    <div className="pointer-events-none fixed inset-0 -z-10 overflow-hidden" aria-hidden>
      <div
        className="absolute inset-0"
        style={{
          background:
            "radial-gradient(ellipse at 20% 10%, rgba(124,92,255,0.18), transparent 55%), radial-gradient(ellipse at 90% 80%, rgba(255,107,157,0.14), transparent 50%), radial-gradient(ellipse at 60% 50%, rgba(79,209,255,0.07), transparent 60%), linear-gradient(180deg, #05060A 0%, #0B0E1A 50%, #05060A 100%)",
        }}
      />
      {stars.map((s, i) => (
        <div
          key={i}
          className="absolute rounded-full"
          style={{
            left: `${s.x}%`,
            top: `${s.y}%`,
            width: `${s.size}px`,
            height: `${s.size}px`,
            background: s.layer === 0 ? "#ffffff" : s.layer === 1 ? "#cdd6ff" : "#ffd9a8",
            boxShadow: `0 0 ${s.size * 3}px rgba(255,255,255,0.7)`,
            animation: `stellaris-twinkle ${s.duration}s ease-in-out ${s.delay}s infinite`,
            opacity: 0.5 + Math.random() * 0.5,
          }}
        />
      ))}
      <div
        className="absolute inset-0"
        style={{
          background:
            "radial-gradient(ellipse 800px 400px at 50% 110%, rgba(124,92,255,0.25), transparent 60%)",
        }}
      />
    </div>
  );
}
