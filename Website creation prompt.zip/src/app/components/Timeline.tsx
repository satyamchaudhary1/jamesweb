import { TIMELINE } from "./data";
import { SectionHeading } from "./SectionHeading";

export function Timeline() {
  return (
    <section id="timeline" className="relative px-6 py-32 lg:px-12">
      <div className="mx-auto max-w-[1400px]">
        <SectionHeading
          eyebrow="06 · TIMELINE"
          title="Mission"
          emphasis="milestones."
          body="From Kourou launchpad to halo orbit at L2 — and every first-light since."
        />
        <div className="stellaris-scrollbar overflow-x-auto pb-6">
          <div className="relative flex min-w-max items-stretch gap-5 px-2">
            <div
              className="absolute left-0 right-0 top-1/2 h-px"
              style={{
                background:
                  "linear-gradient(90deg, transparent, rgba(124,92,255,0.5), rgba(255,107,157,0.6), rgba(255,181,71,0.5), transparent)",
                boxShadow: "0 0 12px rgba(124,92,255,0.4)",
              }}
            />
            {TIMELINE.map((t, i) => (
              <div key={i} className="relative w-[260px]">
                <div
                  className="glass glass-card p-5"
                  style={{
                    marginBottom: i % 2 === 0 ? 90 : 0,
                    marginTop: i % 2 === 0 ? 0 : 90,
                  }}
                >
                  <div
                    className="font-mono"
                    style={{ fontSize: 10, letterSpacing: "0.18em", color: "var(--accent-helium)" }}
                  >
                    {t.date.toUpperCase()}
                  </div>
                  <div className="font-display mt-2" style={{ fontSize: 24, lineHeight: 1.05 }}>
                    {t.title}
                  </div>
                  <p
                    className="mt-2"
                    style={{ color: "var(--text-secondary)", fontSize: 13, lineHeight: 1.6 }}
                  >
                    {t.body}
                  </p>
                </div>
                <div
                  className="absolute left-1/2 top-1/2 size-3 -translate-x-1/2 -translate-y-1/2 rounded-full"
                  style={{
                    background:
                      "linear-gradient(135deg, #FFB547, #FF6B9D)",
                    boxShadow: "0 0 16px rgba(255,181,71,0.8)",
                  }}
                />
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
