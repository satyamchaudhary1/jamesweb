export type Molecule = {
  formula: string;
  name: string;
  atoms: { el: string; x: number; y: number; z: number }[];
  bonds: [number, number][];
  note: string;
};

export const ELEMENT_COLORS: Record<string, string> = {
  H: "#ffffff",
  O: "#ff5252",
  C: "#3a3a3a",
  N: "#4FD1FF",
  S: "#FFD93D",
  Fe: "#FFB547",
  Na: "#c9a0ff",
  He: "#ffd1f0",
};

export const MOLECULES: Molecule[] = [
  {
    formula: "H₂O",
    name: "Water",
    atoms: [
      { el: "O", x: 0, y: 0, z: 0 },
      { el: "H", x: -0.76, y: 0.58, z: 0 },
      { el: "H", x: 0.76, y: 0.58, z: 0 },
    ],
    bonds: [[0, 1], [0, 2]],
    note: "Water ice clouds detected in Jupiter's upper atmosphere by JWST's NIRSpec instrument.",
  },
  {
    formula: "CO₂",
    name: "Carbon Dioxide",
    atoms: [
      { el: "C", x: 0, y: 0, z: 0 },
      { el: "O", x: -1.16, y: 0, z: 0 },
      { el: "O", x: 1.16, y: 0, z: 0 },
    ],
    bonds: [[0, 1], [0, 2]],
    note: "For the first time, JWST tasted the atmosphere of WASP-39b — 700 light-years away — and found CO₂.",
  },
  {
    formula: "CH₄",
    name: "Methane",
    atoms: [
      { el: "C", x: 0, y: 0, z: 0 },
      { el: "H", x: 0.63, y: 0.63, z: 0.63 },
      { el: "H", x: -0.63, y: -0.63, z: 0.63 },
      { el: "H", x: -0.63, y: 0.63, z: -0.63 },
      { el: "H", x: 0.63, y: -0.63, z: -0.63 },
    ],
    bonds: [[0, 1], [0, 2], [0, 3], [0, 4]],
    note: "Methane gives Uranus and Neptune their iconic cyan and azure colors.",
  },
  {
    formula: "NH₃",
    name: "Ammonia",
    atoms: [
      { el: "N", x: 0, y: 0, z: 0 },
      { el: "H", x: 0.94, y: -0.33, z: 0 },
      { el: "H", x: -0.47, y: -0.33, z: 0.81 },
      { el: "H", x: -0.47, y: -0.33, z: -0.81 },
    ],
    bonds: [[0, 1], [0, 2], [0, 3]],
    note: "Ammonia ice crystals form bright bands in Jupiter and Saturn's upper clouds.",
  },
];

export type Planet = {
  id: string;
  symbol: string;
  name: string;
  blurb: string;
  diameter: string;
  distance: string;
  day: string;
  year: string;
  temp: string;
  composition: { label: string; pct: number; color: string }[];
  surface: string;
  jwst: string;
  size: number;
  orbit: number;
  speed: number;
  color: string;
  ring?: boolean;
  ringColor?: string;
  ringTilt?: number;
  bg: string;
  molecules: string[];
};

export const PLANETS: Planet[] = [
  {
    id: "sun",
    symbol: "☀",
    name: "The Sun",
    blurb: "A G-type main-sequence star whose 5,500°C surface bathes nine worlds in light.",
    diameter: "1,391,000 km",
    distance: "—",
    day: "25 Earth days (equator)",
    year: "—",
    temp: "5,500 °C surface · 15,000,000 °C core",
    composition: [
      { label: "Hydrogen", pct: 73, color: "#FFB547" },
      { label: "Helium", pct: 25, color: "#FF6B9D" },
      { label: "Oxygen", pct: 0.77, color: "#4FD1FF" },
      { label: "Carbon", pct: 0.29, color: "#7C5CFF" },
      { label: "Iron + traces", pct: 0.94, color: "#ffffff" },
    ],
    surface: "Plasma — fully ionized hydrogen and helium.",
    jwst: "Light from the Sun's surface takes 8 minutes 20 seconds to reach Earth.",
    size: 110,
    orbit: 0,
    speed: 0,
    color: "#FFB547",
    bg: "radial-gradient(circle at 30% 30%, #fff6c4 0%, #FFB547 35%, #FF6B9D 70%, #7C5CFF 100%)",
    molecules: ["H₂O"],
  },
  {
    id: "mercury",
    symbol: "☿",
    name: "Mercury",
    blurb: "A scorched iron heart with a thin breath of sodium for an atmosphere.",
    diameter: "4,879 km",
    distance: "57.9M km from Sun",
    day: "59 Earth days",
    year: "88 Earth days",
    temp: "−173 °C to 427 °C",
    composition: [
      { label: "Iron core", pct: 70, color: "#FFB547" },
      { label: "Silicate mantle", pct: 28, color: "#a0a0a0" },
      { label: "Exosphere (O, Na, H)", pct: 2, color: "#4FD1FF" },
    ],
    surface: "Cratered silicate crust with polar water ice.",
    jwst: "Not a primary JWST target due to proximity to the Sun.",
    size: 14,
    orbit: 140,
    speed: 30,
    color: "#b8a282",
    bg: "radial-gradient(circle at 35% 30%, #d6c4a8, #8a6f4e 70%, #3a2c1a)",
    molecules: ["H₂O"],
  },
  {
    id: "venus",
    symbol: "♀",
    name: "Venus",
    blurb: "A pressure-cooker world wrapped in sulfuric acid clouds — hotter than Mercury.",
    diameter: "12,104 km",
    distance: "108.2M km from Sun",
    day: "243 Earth days",
    year: "225 Earth days",
    temp: "464 °C surface",
    composition: [
      { label: "CO₂", pct: 96.5, color: "#FFB547" },
      { label: "N₂", pct: 3.5, color: "#4FD1FF" },
      { label: "SO₂ / H₂SO₄ traces", pct: 0.015, color: "#FF6B9D" },
    ],
    surface: "Basaltic volcanic plains beneath sulfuric acid clouds.",
    jwst: "Venus' thick clouds make IR observation difficult — Webb instead studies its night-side glow.",
    size: 24,
    orbit: 190,
    speed: 22,
    color: "#e8c382",
    bg: "radial-gradient(circle at 30% 30%, #ffe6a8, #d99846 60%, #7c4218)",
    molecules: ["CO₂"],
  },
  {
    id: "earth",
    symbol: "🌍",
    name: "Earth",
    blurb: "The only known cradle of life — for now.",
    diameter: "12,742 km",
    distance: "149.6M km from Sun",
    day: "24 hours",
    year: "365.25 days",
    temp: "−88 °C to 58 °C",
    composition: [
      { label: "N₂", pct: 78, color: "#4FD1FF" },
      { label: "O₂", pct: 21, color: "#FF6B9D" },
      { label: "Ar", pct: 0.93, color: "#7C5CFF" },
      { label: "CO₂ + H₂O", pct: 0.07, color: "#FFB547" },
    ],
    surface: "71% liquid water, silicate crust, iron-nickel core.",
    jwst: "Earth is the calibration baseline against which every exoplanet atmosphere is compared.",
    size: 26,
    orbit: 250,
    speed: 18,
    color: "#4FD1FF",
    bg: "radial-gradient(circle at 30% 30%, #b8e6ff, #2c6cb8 55%, #0e2a5a)",
    molecules: ["H₂O", "CO₂"],
  },
  {
    id: "mars",
    symbol: "♂",
    name: "Mars",
    blurb: "A frozen desert under a thin carbon-dioxide sky, where iron-rich rust paints every horizon red.",
    diameter: "6,779 km",
    distance: "227.9M km from Sun",
    day: "24h 37m",
    year: "687 Earth days",
    temp: "−143 °C to 35 °C",
    composition: [
      { label: "CO₂", pct: 95, color: "#FFB547" },
      { label: "N₂", pct: 2.8, color: "#4FD1FF" },
      { label: "Ar", pct: 2, color: "#7C5CFF" },
      { label: "O₂ traces", pct: 0.16, color: "#FF6B9D" },
    ],
    surface: "Fe₂O₃ (rust), silicates, polar water ice caps.",
    jwst: "JWST imaged Mars in September 2022 — resolving CO₂ ice and dust in unprecedented detail.",
    size: 20,
    orbit: 310,
    speed: 14,
    color: "#ff7a4d",
    bg: "radial-gradient(circle at 35% 30%, #ffb695, #c04822 55%, #4a1208)",
    molecules: ["CO₂", "H₂O"],
  },
  {
    id: "jupiter",
    symbol: "♃",
    name: "Jupiter",
    blurb: "A failed star eleven Earths wide, marbled with storms older than civilization.",
    diameter: "139,820 km",
    distance: "778.5M km from Sun",
    day: "9h 56m",
    year: "11.86 Earth years",
    temp: "−145 °C cloud tops",
    composition: [
      { label: "H₂", pct: 90, color: "#ffffff" },
      { label: "He", pct: 10, color: "#FF6B9D" },
      { label: "CH₄ / NH₃ / H₂O", pct: 0.3, color: "#4FD1FF" },
    ],
    surface: "No solid surface — banded hydrogen/helium atmosphere over metallic hydrogen.",
    jwst: "August 2022: JWST captured Jupiter's auroras, rings, and moons Europa & Io in a single near-IR frame.",
    size: 64,
    orbit: 400,
    speed: 8,
    color: "#e6b78a",
    bg: "repeating-radial-gradient(circle at 40% 40%, #f4dcb6 0 6px, #c79462 8px 14px, #8a5a36 16px 22px, #5a3a22 24px 30px)",
    molecules: ["H₂O", "CH₄", "NH₃"],
  },
  {
    id: "saturn",
    symbol: "♄",
    name: "Saturn",
    blurb: "A gas giant girdled by ninety-thousand-kilometer-wide rings of pure water ice.",
    diameter: "116,460 km",
    distance: "1.43B km from Sun",
    day: "10h 42m",
    year: "29.46 Earth years",
    temp: "−178 °C cloud tops",
    composition: [
      { label: "H₂", pct: 96, color: "#ffffff" },
      { label: "He", pct: 3, color: "#FF6B9D" },
      { label: "CH₄", pct: 0.4, color: "#4FD1FF" },
    ],
    surface: "Hydrogen/helium envelope over liquid metallic hydrogen.",
    jwst: "In near-IR, Saturn's rings glow while the planet itself appears dark — methane absorbs sunlight.",
    size: 54,
    orbit: 490,
    speed: 6,
    color: "#f4cf86",
    ring: true,
    ringColor: "rgba(255, 218, 165, 0.5)",
    ringTilt: 18,
    bg: "repeating-radial-gradient(circle at 40% 40%, #fff0c6 0 6px, #e6c188 8px 16px, #b08850 18px 26px)",
    molecules: ["H₂O", "CH₄"],
  },
  {
    id: "uranus",
    symbol: "♅",
    name: "Uranus",
    blurb: "An ice giant rolling on its side, its rings a faint silver halo against deep cyan.",
    diameter: "50,724 km",
    distance: "2.87B km from Sun",
    day: "17h 14m",
    year: "84 Earth years",
    temp: "−224 °C",
    composition: [
      { label: "H₂", pct: 83, color: "#ffffff" },
      { label: "He", pct: 15, color: "#FF6B9D" },
      { label: "CH₄", pct: 2.3, color: "#4FD1FF" },
    ],
    surface: "Methane gives the cyan color; below lies a hot icy mantle.",
    jwst: "April 2023: JWST revealed 11 of Uranus' 13 rings plus a brilliant polar cap.",
    size: 40,
    orbit: 570,
    speed: 5,
    color: "#9be4ff",
    ring: true,
    ringColor: "rgba(155, 228, 255, 0.4)",
    ringTilt: 80,
    bg: "radial-gradient(circle at 35% 30%, #d8f6ff, #5fb6dd 60%, #1c4a73)",
    molecules: ["CH₄", "H₂O", "NH₃"],
  },
  {
    id: "neptune",
    symbol: "♆",
    name: "Neptune",
    blurb: "The wind world — supersonic gusts up to 2,100 km/h tear across its azure clouds.",
    diameter: "49,244 km",
    distance: "4.5B km from Sun",
    day: "16h 6m",
    year: "164.8 Earth years",
    temp: "−214 °C",
    composition: [
      { label: "H₂", pct: 80, color: "#ffffff" },
      { label: "He", pct: 19, color: "#FF6B9D" },
      { label: "CH₄", pct: 1.5, color: "#4FD1FF" },
    ],
    surface: "Dynamic icy mantle of water, ammonia and methane.",
    jwst: "September 2022: JWST captured the clearest view of Neptune's rings in 30+ years.",
    size: 38,
    orbit: 640,
    speed: 4,
    color: "#5d7bff",
    bg: "radial-gradient(circle at 35% 30%, #a8c0ff, #3b54d8 60%, #0c1a55)",
    molecules: ["CH₄", "NH₃"],
  },
];

export type JWSTImage = {
  title: string;
  subtitle: string;
  date: string;
  filter: string;
  distance: string;
  alt: string;
  url: string;
  span: number;
};

export const JWST_IMAGES: JWSTImage[] = [
  {
    title: "Cosmic Cliffs",
    subtitle: "Carina Nebula NGC 3324",
    date: "July 12, 2022",
    filter: "NIRCam · F090W + F187N + F200W",
    distance: "7,600 ly",
    alt: "Towering peaks of cosmic gas and dust glowing orange in the Carina Nebula.",
    url: "https://images.unsplash.com/photo-1656075027874-35a37a27732b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1400",
    span: 2,
  },
  {
    title: "Pillars of Creation",
    subtitle: "M16 Eagle Nebula",
    date: "October 19, 2022",
    filter: "NIRCam · F090W + F470N",
    distance: "6,500 ly",
    alt: "Three pillars of molecular hydrogen rising in the Eagle Nebula.",
    url: "https://images.unsplash.com/photo-1712508818673-f9e3875b94b6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1200",
    span: 1,
  },
  {
    title: "Stephan's Quintet",
    subtitle: "Compact galaxy group",
    date: "July 12, 2022",
    filter: "NIRCam + MIRI composite",
    distance: "290M ly",
    alt: "Five galaxies tangled in gravitational dance.",
    url: "https://images.unsplash.com/photo-1711559383256-d1e36626d9a7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1200",
    span: 1,
  },
  {
    title: "Southern Ring Nebula",
    subtitle: "NGC 3132",
    date: "July 12, 2022",
    filter: "NIRCam + MIRI",
    distance: "2,500 ly",
    alt: "Concentric shells of expelled gas from a dying star.",
    url: "https://images.unsplash.com/photo-1717704067715-57d14b090290?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1200",
    span: 1,
  },
  {
    title: "SMACS 0723",
    subtitle: "First Deep Field",
    date: "July 11, 2022",
    filter: "NIRCam · 12.5 hours",
    distance: "4.6B ly",
    alt: "Galaxy cluster lensing light from the early universe.",
    url: "https://images.unsplash.com/photo-1679615845580-8691c78fd7d3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1400",
    span: 2,
  },
  {
    title: "Cartwheel Galaxy",
    subtitle: "ESO 350-40",
    date: "August 2, 2022",
    filter: "NIRCam + MIRI",
    distance: "500M ly",
    alt: "Ring galaxy formed by a high-speed collision.",
    url: "https://images.unsplash.com/photo-1710270822133-803dbff85a32?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1200",
    span: 1,
  },
  {
    title: "Phantom Galaxy",
    subtitle: "M74",
    date: "August 29, 2022",
    filter: "MIRI · 7.7 + 10 + 21 μm",
    distance: "32M ly",
    alt: "Face-on spiral galaxy with delicate filaments.",
    url: "https://images.unsplash.com/photo-1711559382658-0756a8499056?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1400",
    span: 2,
  },
  {
    title: "Tarantula Nebula",
    subtitle: "30 Doradus",
    date: "September 6, 2022",
    filter: "NIRCam · F090W + F200W",
    distance: "161,000 ly",
    alt: "Largest known star-forming region in the Local Group.",
    url: "https://images.unsplash.com/photo-1677926405168-fa86268b7295?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1200",
    span: 1,
  },
  {
    title: "Jupiter with Rings",
    subtitle: "Auroras + Europa + Io",
    date: "August 22, 2022",
    filter: "NIRCam · F212N + F360M",
    distance: "778M km",
    alt: "Jupiter glowing with auroras over polar caps.",
    url: "https://images.unsplash.com/photo-1711560026656-814d5a9e980f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1200",
    span: 1,
  },
  {
    title: "Neptune & Rings",
    subtitle: "Clearest view in 30 years",
    date: "September 21, 2022",
    filter: "NIRCam · F140M",
    distance: "4.5B km",
    alt: "Neptune appearing bone-white with delicate dust rings.",
    url: "https://images.unsplash.com/photo-1712508818392-1d1b3cfafb43?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1200",
    span: 1,
  },
  {
    title: "Uranus & Rings",
    subtitle: "11 of 13 rings revealed",
    date: "April 6, 2023",
    filter: "NIRCam · F140M + F300M",
    distance: "2.87B km",
    alt: "Uranus with brilliant polar cap and ring system.",
    url: "https://images.unsplash.com/photo-1711994872310-99265f37e1f1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1200",
    span: 1,
  },
  {
    title: "WR 124",
    subtitle: "Wolf-Rayet star",
    date: "March 14, 2023",
    filter: "NIRCam + MIRI",
    distance: "15,000 ly",
    alt: "Dying massive star casting off its outer layers.",
    url: "https://images.unsplash.com/photo-1711995364023-d8b985bc50cf?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1400",
    span: 2,
  },
];

export const TIMELINE = [
  { date: "Dec 25, 2021", title: "Launch", body: "Ariane 5 rocket lifts JWST from Kourou, French Guiana." },
  { date: "Jan 8, 2022", title: "Sunshield deployed", body: "Five tennis-court-sized layers tensioned and locked." },
  { date: "Jan 24, 2022", title: "Arrival at L2", body: "Webb settles into halo orbit 1.5M km from Earth." },
  { date: "Mar 11, 2022", title: "Mirror alignment", body: "18 hexagons act as a single 6.5 m mirror." },
  { date: "Jul 11, 2022", title: "First Deep Field", body: "SMACS 0723 — the deepest infrared view of the cosmos ever." },
  { date: "Jul 12, 2022", title: "First image suite", body: "Carina, Stephan's Quintet, Southern Ring, WASP-96b." },
  { date: "Aug 22, 2022", title: "Jupiter in IR", body: "Auroras, rings and moons in a single frame." },
  { date: "Sep 21, 2022", title: "Neptune's rings", body: "Clearest view since Voyager 2." },
  { date: "Jan 11, 2023", title: "LHS 475 b", body: "First exoplanet confirmed by JWST." },
  { date: "Mar 22, 2023", title: "WASP-39b CO₂", body: "First-ever exoplanet CO₂ detection." },
  { date: "Apr 6, 2023", title: "Uranus' rings", body: "11 of 13 rings revealed alongside polar cap." },
  { date: "Today", title: "Still observing…", body: "Webb continues its 20-year nominal mission." },
];

export const EXOPLANETS = [
  {
    id: "wasp39b",
    name: "WASP-39b",
    type: "Hot Jupiter",
    distance: "700 light-years",
    temp: "≈ 900 °C",
    blurb: "For the first time in human history, we tasted the atmosphere of a world 700 light-years away — and found carbon dioxide.",
    bg: "radial-gradient(circle at 35% 30%, #ffd58a, #ff6b3d 55%, #5a1a08)",
    molecules: ["CO₂", "H₂O"],
  },
  {
    id: "trappist1e",
    name: "TRAPPIST-1e",
    type: "Rocky · habitable zone",
    distance: "40 light-years",
    temp: "≈ −22 °C",
    blurb: "One of seven Earth-sized worlds orbiting an ultra-cool dwarf — three sit in the habitable zone.",
    bg: "radial-gradient(circle at 30% 30%, #cfa37a, #6e4a2c 60%, #1c1108)",
    molecules: ["H₂O"],
  },
  {
    id: "lhs475b",
    name: "LHS 475 b",
    type: "Rocky · Earth-sized",
    distance: "41 light-years",
    temp: "≈ 100 °C",
    blurb: "The first exoplanet confirmed by JWST (January 2023) — Earth-sized, bone-dry, baked.",
    bg: "radial-gradient(circle at 30% 30%, #d4d4d4, #6b6b6b 60%, #1a1a1a)",
    molecules: ["CO₂"],
  },
];

export const DEEP_SKY = [
  { id: "carina", x: 22, y: 38, type: "Nebula", name: "Carina Nebula", distance: "7,600 ly", note: "A stellar nursery — new stars forming inside." },
  { id: "eagle", x: 64, y: 28, type: "Nebula", name: "Eagle Nebula", distance: "6,500 ly", note: "The Pillars of Creation rise here." },
  { id: "ring", x: 80, y: 62, type: "Nebula", name: "Southern Ring", distance: "2,500 ly", note: "Gas shells expelled by a dying star." },
  { id: "tarantula", x: 36, y: 70, type: "Nebula", name: "Tarantula Nebula", distance: "161,000 ly", note: "Largest star-forming region in the Local Group." },
  { id: "phantom", x: 14, y: 60, type: "Galaxy", name: "Phantom Galaxy (M74)", distance: "32M ly", note: "Face-on spiral, perfectly geometric." },
  { id: "cartwheel", x: 48, y: 50, type: "Galaxy", name: "Cartwheel Galaxy", distance: "500M ly", note: "A ring forged by a galactic collision." },
  { id: "smacs", x: 72, y: 84, type: "Galaxy", name: "SMACS 0723", distance: "4.6B ly", note: "The first JWST Deep Field." },
  { id: "stephan", x: 58, y: 16, type: "Galaxy", name: "Stephan's Quintet", distance: "290M ly", note: "Five galaxies, four locked in gravity." },
  { id: "trappist", x: 28, y: 18, type: "Star Cluster", name: "TRAPPIST-1", distance: "40 ly", note: "Seven Earth-sized worlds." },
  { id: "ngc7331", x: 88, y: 38, type: "Galaxy", name: "NGC 7331", distance: "40M ly", note: "Milky Way's almost-twin." },
];
