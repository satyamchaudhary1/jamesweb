1. PROJECT BRIEF
Design Stellaris — a single-page interactive web experience that showcases every major image captured by the James Webb Space Telescope (JWST) and lets users explore planets, stars, nebulae, galaxies, and exoplanets through realistic, clickable 3D models. On hover, contextual info surfaces inside glassmorphic panels. On click, the camera flies into the object and reveals deep info plus an interactive 3D molecular/elemental composition view.
The site should feel like a NASA mission console crossed with an Apple product page — cinematic, scientific, premium, and tactile.
Primary user goal: "Show me a beautiful image from JWST, let me understand what I'm looking at, then let me touch it in 3D."

2. DESIGN SYSTEM
2.1 Color Palette
Dark, deep-space base with cosmic accents. Use these exact tokens:
--bg-void:          #05060A   /* primary background */
--bg-deep:          #0B0E1A   /* secondary surfaces */
--bg-nebula:        #141832   /* tertiary / cards */

--glass-white:      rgba(255, 255, 255, 0.06)
--glass-border:     rgba(255, 255, 255, 0.12)
--glass-highlight:  rgba(255, 255, 255, 0.18)

--accent-plasma:    #7C5CFF   /* primary CTA - electric violet */
--accent-stellar:   #FF6B9D   /* hot pink / supernova */
--accent-helium:    #4FD1FF   /* cyan / ionized gas */
--accent-gold:      #FFB547   /* JWST mirror gold */

--text-primary:     #FFFFFF
--text-secondary:   rgba(255, 255, 255, 0.72)
--text-tertiary:    rgba(255, 255, 255, 0.48)

--gradient-cosmos:  linear-gradient(135deg, #7C5CFF 0%, #FF6B9D 50%, #FFB547 100%)
--gradient-jwst:    radial-gradient(circle, #FFB547 0%, #FF6B9D 40%, #7C5CFF 100%)
2.2 Typography

Display / Hero: "Instrument Serif" (italic for emphasis) — large, editorial, 80–160px
Headings: "Space Grotesk" — 32–56px, tight tracking (-0.02em)
Body: "Inter" — 15–17px, line-height 1.6
Data / Mono: "JetBrains Mono" — 12–14px (for coordinates, masses, distances)
Mix serif display with sans body for that "editorial science magazine" feel.

2.3 Glassmorphism Spec
Every floating panel uses:

background: rgba(255, 255, 255, 0.06)
backdrop-filter: blur(24px) saturate(180%)
border: 1px solid rgba(255, 255, 255, 0.12)
border-radius: 20px (cards) / 28px (large panels) / 999px (pills)
box-shadow: 0 8px 32px rgba(0,0,0,0.4), inset 0 1px 0 rgba(255,255,255,0.08)
Subtle inner highlight at top edge.

2.4 Motion Principles

All transitions use cubic-bezier (0.22, 1, 0.36, 1) — smooth, decelerating.
Hover delays: 80ms in, 160ms out.
3D camera moves: 1.2s ease-in-out.
Parallax starfield on scroll (3 layers, different speeds).
Subtle constant rotation on all 3D bodies (0.05–0.2 rpm depending on object).


3. SITE ARCHITECTURE
Single-page application with smooth-scroll sections + a persistent 3D canvas overlay for object exploration.
0. Boot Sequence (loading)
1. Hero / Mission Console
2. JWST Image Gallery (the masterpieces)
3. Solar System Orrery (interactive 3D planets)
4. Deep Sky Explorer (nebulae, galaxies, star clusters)
5. Exoplanet Lab (TRAPPIST-1, WASP-39b, etc.)
6. Composition Lab (3D molecules / elements)
7. Timeline of JWST Discoveries
8. About JWST (the telescope itself in 3D)
9. Footer / Credits
A persistent floating nav (glass pill, top-center) lets users jump between sections. A sidebar mini-map shows current location in the cosmos.

4. PAGE-BY-PAGE DETAIL
4.1 Boot Sequence

Black screen, JWST mirror hexagons assemble into the famous gold honeycomb.
Type-on text: "Calibrating mirrors… Cooling instruments to -233°C… Aligning with L2…"
Progress bar (thin, plasma gradient).
Ends with a flash → hero reveals.

4.2 Hero / Mission Console

Massive 3D rotating JWST telescope model, center-right.
Left side: serif italic headline — "Look closer at the universe."
Subhead: "Every image. Every world. Every atom. Captured by the James Webb Space Telescope."
Two CTAs in glass pills: [Explore Gallery] and [Launch Tour].
Bottom strip: live-counter style stats —

"1.5M km from Earth · 6.5m mirror · -233°C · 13.6B years observed"


Animated starfield + slow cosmic dust particles drifting.

4.3 JWST Image Gallery
A masonry-style grid of real JWST captures. Each card:

Full-bleed JWST image (use placeholders: "Carina Nebula", "Pillars of Creation", etc.)
On hover: card tilts 6° (3D parallax), glass info panel slides up from bottom showing name + date captured + filter used.
Click: opens immersive viewer — image fills screen with zoom/pan controls and an annotated science panel on the right (glass).

Featured captures to include:

Cosmic Cliffs (Carina Nebula NGC 3324) — July 12, 2022
Pillars of Creation (M16) — October 19, 2022
Stephan's Quintet — July 12, 2022
Southern Ring Nebula (NGC 3132) — July 12, 2022
SMACS 0723 Deep Field — July 11, 2022
Cartwheel Galaxy — August 2, 2022
Phantom Galaxy (M74) — August 29, 2022
Tarantula Nebula (30 Doradus) — September 6, 2022
Jupiter with rings & auroras — August 22, 2022
Neptune with rings — September 21, 2022
Uranus with rings — April 6, 2023
WR 124 (Wolf-Rayet star) — March 14, 2023

4.4 Solar System Orrery
Top-down + tilted 3D view of the Sun and 8 planets, all orbiting at scaled-down but visible speeds. Saturn's rings, Jupiter's bands, Earth's clouds — all realistic textures.

Hover any planet → glass tooltip appears with quick stats (mass, diameter, distance, day length).
Click a planet → camera flies in over 1.2s, the orrery dims, and a full Planet Detail Panel slides in from the right (glass, 480px wide):

Tabs: Overview · Composition · Atmosphere · Moons · JWST View
"View in 3D" button → opens fullscreen rotatable 3D model.
"See Molecules" button → jumps to Composition Lab pre-filtered to that planet.



Include a scale toggle: "Realistic" vs "Visible" (real scale makes planets dots, so default to visible).
4.5 Deep Sky Explorer
A starfield map you can pan/zoom (like Google Maps for the sky). Markers for nebulae, galaxies, star clusters. Each marker has a faint pulsing glow.

Filter chips (glass pills): All · Nebulae · Galaxies · Star Clusters · Black Holes.
Click a marker → object slides in as a 3D model in the center, info on the right.

4.6 Exoplanet Lab
Showcase JWST's exoplanet discoveries.

3D rendered exoplanets in a row, slowly rotating.
Click → opens comparison view with Earth side-by-side (size, temperature, atmosphere).
Highlight: TRAPPIST-1 system (7 Earth-sized planets, mini orrery), WASP-39b (first CO₂ detection on exoplanet), LHS 475 b.

4.7 Composition Lab ⭐ (signature feature)
This is where the molecular 3D view lives.

Layout: object preview on the left (the celestial body), periodic-table-style breakdown in the middle, 3D molecule viewer on the right.
User selects a body → see its elemental pie chart (animated, glass donut) + list of molecules.
Click any molecule (e.g., H₂O, CO₂, CH₄, NH₃) → rotatable 3D ball-and-stick model appears with element labels.

Hydrogen: white sphere
Oxygen: red sphere
Carbon: dark gray sphere
Nitrogen: blue sphere
Sulfur: yellow sphere
Iron: orange sphere


Below the molecule: a small card explaining its role ("Water ice clouds detected in Jupiter's upper atmosphere by JWST's NIRSpec instrument").

4.8 Timeline of JWST Discoveries
Horizontal scroll timeline (glass cards on a glowing track). Each card = a milestone.

Dec 25, 2021: Launch
Jan 24, 2022: L2 arrival
Jul 11, 2022: First Deep Field image
… through current date.

4.9 About JWST
Massive 3D explorable model of the telescope itself.

Click any part → label + spec (Primary Mirror, Sunshield, NIRCam, MIRI, FGS/NIRISS, NIRSpec).
Cutaway animation showing how light travels through.


5. INTERACTIONS — THE HOVER & CLICK MODEL
Every celestial body follows this contract:
StateBehaviorDefaultSlow rotation, subtle ambient glowHoverBody slightly scales up (1.05x), glow intensifies, glass tooltip fades in at cursor with name + 2 key statsClickCamera dollies in, body centers, full glass detail panel slides in (right side or bottom sheet on mobile)Detail OpenBackground blurs (8px) and dims to 40%ClosePress ESC or click background — camera returns to origin
Cursor: Custom — a small glowing reticle that changes to a "+" when over an interactive body.

6. CELESTIAL BODY CONTENT (USE THIS DATA)
☀️ THE SUN

Type: G-type main-sequence star (G2V)
Diameter: 1,391,000 km
Mass: 1.989 × 10³⁰ kg
Surface temp: 5,500 °C
Core temp: 15,000,000 °C
Composition: Hydrogen 73%, Helium 25%, Oxygen 0.77%, Carbon 0.29%, Iron 0.16%, traces of Ne, N, Si, Mg, S
Molecules to show: H₂ (rare, mostly atomic), He
Fun fact: Light from the Sun's surface takes 8 minutes 20 seconds to reach Earth.

☿ MERCURY

Diameter: 4,879 km
Distance from Sun: 57.9M km
Day: 59 Earth days · Year: 88 Earth days
Composition: Iron core (~70% of mass), silicate mantle/crust. Thin exosphere of O, Na, H, He, K.
Molecules to show: Atomic Na, atomic O, H₂O ice (at poles!)
JWST note: Not a primary JWST target due to proximity to Sun.

♀ VENUS

Diameter: 12,104 km
Surface temp: 464 °C (hottest planet)
Composition (atmosphere): CO₂ 96.5%, N₂ 3.5%, traces of SO₂, H₂SO₄ (sulfuric acid clouds), H₂O, CO
Surface: Basaltic rock, volcanic plains
Molecules to show: CO₂, H₂SO₄, SO₂, N₂

🌍 EARTH

Diameter: 12,742 km
Composition (atmosphere): N₂ 78%, O₂ 21%, Ar 0.93%, CO₂ 0.04%, H₂O variable
Surface: 71% water, silicate crust, iron-nickel core
Molecules to show: N₂, O₂, H₂O, CO₂
Note: "The only known cradle of life — for now."

♂ MARS

Diameter: 6,779 km
Composition (atmosphere): CO₂ 95%, N₂ 2.8%, Ar 2%, O₂ 0.16%
Surface: Iron(III) oxide (Fe₂O₃ — "rust"), silicates, water ice at poles
Molecules to show: CO₂, Fe₂O₃, H₂O (ice), CH₄ (trace, debated)
JWST note: JWST imaged Mars in Sept 2022 — saw CO₂ ice and dust in detail.

♃ JUPITER

Diameter: 139,820 km (11x Earth)
Composition: H₂ 90%, He 10%, traces of CH₄, NH₃, H₂O, H₂S, hydrocarbons
Storm: Great Red Spot — a 350-year-old storm wider than Earth.
Molecules to show: H₂, He, CH₄, NH₃, H₂O
JWST note: Captured auroras + ring system + Europa/Io in same frame, Aug 2022.

♄ SATURN

Diameter: 116,460 km
Composition: H₂ 96%, He 3%, CH₄ 0.4%, NH₃, HD, ethane
Rings: 99.9% water ice, traces of rocky material
Molecules to show: H₂, He, CH₄, H₂O (ice)
JWST note: JWST captured Saturn in near-IR — rings glow, planet appears dark.

♅ URANUS

Diameter: 50,724 km
Composition: H₂ 83%, He 15%, CH₄ 2.3% (methane gives the cyan color)
Tilt: 98° — rotates on its side
Molecules to show: H₂, He, CH₄, H₂O ice, NH₃ ice
JWST note: April 2023 image revealed 11 of its 13 rings + polar cap.

♆ NEPTUNE

Diameter: 49,244 km
Composition: H₂ 80%, He 19%, CH₄ 1.5%
Winds: Fastest in solar system — up to 2,100 km/h
Molecules to show: H₂, He, CH₄, H₂O, NH₃
JWST note: Sept 2022 image — clearest view of rings in 30+ years.

🌌 NEBULAE & DEEP SKY
Carina Nebula (NGC 3324) — "Cosmic Cliffs"

Distance: 7,600 light-years
Composition: Mostly H₂ gas, dust (silicates, carbon), traces of He, O, N
A stellar nursery — new stars forming inside.

Pillars of Creation (M16 Eagle Nebula)

Distance: 6,500 light-years
Composition: Molecular hydrogen (H₂), dust, ionized gas (H II regions)
Pillars are being eroded by UV radiation from nearby massive stars.

Southern Ring Nebula (NGC 3132)

Distance: 2,500 light-years
A planetary nebula — gas shells expelled by a dying star.
Composition: Ionized H, He, O III, N II, dust shells

Tarantula Nebula (30 Doradus)

Distance: 161,000 light-years (in Large Magellanic Cloud)
Largest known star-forming region in Local Group.

🪐 EXOPLANETS
WASP-39b

Type: Hot Jupiter, 700 light-years away
Composition: H₂, He, CO₂ (first ever detected on exoplanet by JWST), H₂O, CO, SO₂, Na, K
Surface temp: ~900 °C

TRAPPIST-1 system

7 Earth-sized rocky planets, 40 light-years away
TRAPPIST-1b: bare rock, no atmosphere (JWST 2023)
TRAPPIST-1e, f, g: in habitable zone

LHS 475 b

First exoplanet confirmed by JWST (Jan 2023)
Earth-sized, 41 light-years away, rocky


7. ADDITIONAL FEATURES TO ENHANCE EXPERIENCE

Time Machine slider — drag to see JWST captures by date.
Compare Mode — select 2 bodies, see side-by-side stats (size, mass, composition).
Distance Visualizer — "How far is this from Earth?" with a zooming animation.
Cosmic Soundscape toggle — ambient sounds (sonification of JWST data from NASA's actual program).
Scale Tool — drag a slider to see "If the Sun were a basketball, Earth would be…"
Random Cosmos button — surprises you with a random JWST image + body.
Bookmark constellation — save favorites to a personal "star map."
AR view (mobile) — point phone, see planet in your room.
Quiz mode — "Which gas dominates Saturn's atmosphere?" with glass card UI.
Newsletter capture — "Get notified when JWST releases a new image" — glass form, plasma button.
Language toggle — EN / ES / FR / JA / HI.
Reduce-motion mode — accessibility-respectful.
Easter egg: Konami code triggers a black hole that warps the page for 3 seconds.


8. RESPONSIVE BEHAVIOR

Desktop (≥1280px): Full 3D experience, side panels, hover interactions.
Tablet (768–1279px): 3D stays, panels become bottom sheets, hover → tap.
Mobile (<768px): Simplified 3D (single body at a time), card stack UI, swipe between bodies, all hover content moves to tap.


9. ACCESSIBILITY

WCAG AA contrast minimum on all text over glass (test against the darkest possible backdrop).
All 3D interactions have keyboard equivalents (Tab through bodies, Enter to open).
Alt text for every JWST image describing what's shown.
Captions for any audio.
Prefers-reduced-motion respected.


10. TECHNICAL HINTS FOR FIGMA MAKE

Use Three.js / React Three Fiber for 3D bodies and molecules.
Use GLSL shaders for the Sun's surface (noise + emission) and gas giants' bands (flow noise).
Use EnvironmentMap with HDRI for realistic planet lighting.
Lazy-load 3D models per section (don't load everything upfront).
Compress textures (KTX2 / Basis).
Use Framer Motion for panel slides and glass card transitions.
Use shader-based blur for glassmorphism on canvas overlays (CSS backdrop-filter doesn't work over WebGL).


11. TONE OF VOICE
Confident, awe-struck, scientifically precise but never dry. Examples:

❌ "Mars is the fourth planet from the Sun."
✅ "Mars — a frozen desert under a thin carbon dioxide sky, where iron-rich rust paints every horizon red."
❌ "Carbon dioxide was detected on WASP-39b."
✅ "For the first time in human history, we tasted the atmosphere of a world 700 light-years away — and found carbon dioxide."


12. DELIVERABLE
A high-fidelity, interactive Figma Make prototype with:

All sections functional and navigable
At least 5 planets fully clickable with detail panels
At least 3 JWST images viewable in immersive mode
The Composition Lab working for at least 4 molecules (H₂O, CO₂, CH₄, NH₃)
The JWST telescope 3D model in the About section
Smooth scroll, glass panels, and starfield throughout

Vibe reference: Imagine if Apple, NASA, and Linear designed a planetarium together. That's Stellaris.